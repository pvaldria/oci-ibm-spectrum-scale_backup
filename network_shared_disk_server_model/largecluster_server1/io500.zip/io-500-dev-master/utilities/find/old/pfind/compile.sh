#!/bin/bash

cc=cc

$cc -o pfind mpi_find.c

echo "Copy the executable pfind in the proposal-draft folder"
