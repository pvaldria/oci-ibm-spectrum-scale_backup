#!/bin/sh
#
# Copyright (c) 2016 SAS Institute Inc. 
# Unpublished - All Rights Reserved 
#
# =========================
# Gather System Info Script
# Version 1.3.38
# Build 20160316
# =========================
#
# gather_info.sh
# This script gathers and compresses a select set of information
#   about the system into gather_info[DATE].tar.gz.
#
# USAGE
#./gather_info.sh [OPTION]
#   --help		display this help and exit
#   --version	output version information and exit
#
# RETURN CODES
#  0  : Success
# -1  : Usage error or invalid parameter
#  1  : General error
#
# ====================================================================
# REVISION HISTORY
# ====================================================================
# Date        Developer   Change
# ----        ---------   ------
# 2015-09-28  jikuel      Coded
# 2015-10-05  jikuel	  Added new set of information to gather
# 2015-10-13  jikuel	  Commented and cleaned up code
# 2015-11-05  jikuel	  Refining functions and testing
# 2015-11-30  jikuel	  Added new set of info and refined functions
# 2016-03-02  jikuel	  New commands and added script to tarball
# 2016-03-16  jikuel	  Gather info for EMC PowerPath and Veritas 
#							Volume Manager

# ====================================================================
# COMMON VARIABLES
# ====================================================================
SCRIPT_NAME="Gather System Info"
SCRIPT_VERSION="1.3.38"
SCRIPT_BUILD_ID="201603161338"
BASEDIR=$(dirname $(readlink -f $0))
BASEDIR_SHORT=$(dirname $0)
LOG="${BASEDIR}"/gather_info.log
SYS_INFO="${BASEDIR}"/system_info
DATE=`date +%Y%m%d`
FQDN=""
HOSTNAME=""

# ====================================================================
# SCRIPT-SPECIFIC VARIABLES
# ====================================================================
WARNINGS=0
RHEL_VERSION=""
PROCS="cpuinfo meminfo diskstats cmdline interrupts partitions"
ETC_FILES="redhat-release fstab multipath.conf"
ETC_DIRS="udev lvm"
OTHER_FILES="var/log:dmesg boot/grub:menu.lst etc/security:limits.conf,access.conf"
CMDS=("ifconfig -a"
	  "getconf PAGESIZE"
	  "tuned-adm active"
	  "mount"
	  "multipath -ll"
	  "powermt version"
	  "powermt display options"
	  "powermt display dev=all"
	  "powermt display hba_mode"
	  "vxdmpadm getsubpaths"
	  "vxdisk list"
	  "vxddladm list devices"
	  "uname -a"
	  "lvs -o name,vg_name,size,attr,lv_size,stripes,stripesize,lv_read_ahead"
	  "pvs"
	  "vgs"
	  "df -hT"
	  "lscpu"
	  "blockdev --report"
	  "dmidecode")

# ====================================================================
# FUNCTIONS
# ====================================================================

# Show usage details
show_usage() {
echo -e "Usage: ./gather_info.sh [OPTION]\n
Gathers and compresses a select set of information
   about the system into gather_info_[HOSTNAME]_[DATE].tar.gz.

   --help	display this help and exit
   --version	output version information and exit
   
Supported operating systems are RHEL 6.x and RHEL 7.x.

Script must be run as root.\n"
}

# Show version details
show_version() {
echo -e "
${SCRIPT_NAME}
Version: ${SCRIPT_VERSION}
Build: ${SCRIPT_BUILD_ID}

Copyright (c) 2015 SAS Institute Inc. 
Unpublished - All Rights Reserved 

Written by Jim Kuell.\n"
}

# Notify the user that 1 or more warnings have been found
warnings_found() {
	echo -e "Warnings found. Please see '${LOG}' for more details.\n"
}

# Notify the user that 1 or more errors have been found
errors_found() {
	echo -e "Errors found. Please see '${LOG}' for more details.\n"
}

# Notify the user that the operating system on which they
#	are attemtping to run this script is not supported
invalid_os() {
	echo "Operating system is not supported. Supported operating systems are"
	echo -e "   RHEL 6.x and RHEL 7.x. See '${LOG}' for more information.\n"
}

# Catch and print syserr messages to the log that are triggered
#	when executing commands and throw the WARNINGS flag
check_warning() {
	if [ "${MSG}" != "" ];
	then
		echo -e "WARNING:\n------" >> "${LOG}"
		echo -e "$MSG" >> "${LOG}"
		echo "------" >> "${LOG}"
		WARNINGS=1
	fi
	
	echo "" >> "${LOG}"
}

# Check to see if a gather_info_[DATE].tar.gz was already created today. If
#	so, append '.old' to previous file. If gather_info_[DATE].tar.gz.old
#	exists, throw an error and notify user.
check_existing_files() {
	if [ -f "${CURR_FILE}" ];
	then
		echo -e "WARNING: File '${CURR_FILE}' already exists. Moving to '${CURR_FILE}.old'\n" >> "${LOG}"
		WARNINGS=1
		if [ -f "${CURR_FILE}.old" ];
		then
			echo "ERROR: File '${CURR_FILE}.old' already exists. Cannot create backup of previous '${CURR_FILE}'. Remove or backup this file before continuing. Exiting now..." >> "${LOG}"
			errors_found
			exit 1
		else
			mv $CURR_FILE "${CURR_FILE}.old"
		fi
	fi
}

# Create the target directory if it has not already been created
#	in the system_info temporary directory
create_new_dir() {
	echo "INFO: Creating directory '${SYS_INFO}/${DIR}'." >> "${LOG}"

	if [ ! -d "${SYS_INFO}/${DIR}" ];
	then
		MSG=$( mkdir "${SYS_INFO}/${DIR}" 2>&1 )
		check_warning
	else
		echo -e "INFO: Directory '${SYS_INFO}/${DIR}' has already been created. Continuing...\n" >> "${LOG}"
	fi
}

# Initialize the program - validate the environment and
#	error check before attempting to gather system info
initialize() {
	# Set these here so we can verify that the script is being run
	#	as root prior to doing so
	FQDN=`(hostname -f || cat /etc/hostname) 2> /dev/null?`
	HOSTNAME=`hostname -s`
	
	if [ -f "${LOG}" ];
	then
		echo "File '${LOG}' already exists. Please delete"
		echo -e "   this before continuing.\n"
		exit 1
	fi
	
	if [[ "${FQDN}" != "hostname: Name or service not known" ]];
	then
		echo "HOSTNAME: ${FQDN}" > "${LOG}"
	else
		echo "HOSTNAME: ${HOSTNAME}" > "${LOG}"
	fi
	
	echo -e "DATE: ${DATE}\n" >> "${LOG}"
	
	# Verify that a gather_info tar does not exist from today
	CURR_FILE="${BASEDIR}/gather_info_${HOSTNAME}_${DATE}.tar"
	check_existing_files
	
	# Verify that a gather_info tar.gz does not exist from today
	CURR_FILE="${BASEDIR}/gather_info_${HOSTNAME}_${DATE}.tar.gz"
	check_existing_files
	
	# Verify that we're running on either RHEL 6 or 7
	if [ -f /etc/redhat-release ];
	then
		RHEL_RELEASE="/etc/redhat-release"
		MATCH_STRING="Red Hat Enterprise Linux Server release "
		
		if [[ `cat "${RHEL_RELEASE}"` == "${MATCH_STRING}"* ]];
		then
			echo "INFO: Checking RHEL version." >> "${LOG}"
			
			# Get the major release version from /etc/redhat-release
			RHEL_VERSION=`awk '{ print substr($7,0,1)}' "${RHEL_RELEASE}"`
			if [ $RHEL_VERSION -eq 6 -o $RHEL_VERSION -eq 7 ];
			then
				echo -e "INFO: RHEL ${RHEL_VERSION} is supported. Continuing...\n" >> "${LOG}"
			else
				invalid_os
				echo "ERROR: unsupported RHEL version detected in '/etc/redhat-release.' Exiting..." >> "${LOG}"
				errors_found
				exit 1
			fi
		else
			invalid_os
			echo "ERROR: unsupported RHEL version detected in '/etc/redhat-release.' Exiting..." >> "${LOG}"
			errors_found
			exit 1
		fi
	else
		invalid_os
		echo "ERROR: '/etc/redhat-release' does not exist. Operating system is not supported. Exiting..." >> "${LOG}"
		errors_found
		exit 1
	fi
	
	# Verify that the tmp 'system_info' directory does not exit
	if [ -d "${SYS_INFO}" ];
	then
		echo "Directory './system_info/' already exists. Please delete"
		echo -e "   or rename this before continuing.\n"
		exit 1
	fi
	
	echo "INFO: Creating directory './system_info'." >> "${LOG}"
	MSG=$( mkdir "${SYS_INFO}" 2>&1 )
	check_warning
	
	# Verify that the 'system_info' directory was created
	if [ ! -d "${SYS_INFO}" ];
	then
		echo -e "ERROR: Unable to create directory './system_info/'. Exiting now...\n" >> "${LOG}"
		errors_found
		exit 1
	fi
}

# Copy individual files to their respective directory structure
#	within ./system_info/
copy_files() {
	SOURCE="/${DIR}/${FILE}"
	DEST="${SYS_INFO}/${DIR}/${FILE}"
	
	echo "INFO: Copying file '${SOURCE}' to '${DEST}'." >> "${LOG}"
	
	if [ -f "${SOURCE}" ];
	then
		MSG=$( cp -p ${SOURCE} ${DEST} 2>&1)
		check_warning
	else
		echo -e "WARNING: File '${SOURCE}' does not exist. Continuing...\n" >> "${LOG}"
		WARNINGS=1
	fi
}

# Copy directories to their respective directory structure
#	within ./system_info/
copy_dirs() {
	SOURCE="/${DIR}/${SUB_DIR}/"
	DEST="${SYS_INFO}/${DIR}/${SUB_DIR}"

	echo "INFO: Copying directory '${SOURCE}' to '${DEST}'." >> "${LOG}"
	
	if [ -d "${SOURCE}" ];
	then
		MSG=$( cp -rp ${SOURCE} ${DEST} 2>&1)
		check_warning
	else
		echo -e "WARNING: File '${SOURCE}' does not exist. Continuing...\n" >> "${LOG}"
		WARNINGS=1
	fi
}

# Copy the output of the set commands to the 'commands' directory
#	within ./system_info/
copy_cmds() {
	echo "INFO: Creating directory '${SYS_INFO}/commands'." >> "${LOG}"
	MSG=$( mkdir "${SYS_INFO}"/commands 2>&1 )
	check_warning
	
	if [ -d "${SYS_INFO}"/commands ];
	then
		for CMD in "${CMDS[@]}";
		do
			test_exists=`type -p ${CMD}`
			DEST="${SYS_INFO}/commands/${CMD// /_}.txt"
			
			echo "INFO: Copying output of command '${CMD}' to ${DEST}." >> "${LOG}"
			
			if [ -z "${test_exists}" ];
			then
				echo -e "WARNING: Command '${CMD}' not found.\n" >> "${LOG}"
				WARNINGS=1
			else
				MSG=$( ${CMD} 2>&1 >${DEST})
				check_warning
			fi
		done
	else
		echo -e "WARNING: Cannot create directory '${SYS_INFO}/usr'. Continuing...\n" >> "${LOG}"
		WARNINGS=1
	fi
}

# Tuned profiles are located in different locations depending upon
#	whether the OS is RHEL 6.x or RHEL 7.x. Verify the RHEL version
#	and copy the tuned profiles to their respective directory
#	structure within ./system_info/
copy_tuned() {
	if [ $RHEL_VERSION -eq 6 ];
	then
		DIR="etc"
		SUB_DIR="tune-profiles"
		copy_dirs
	elif [ $RHEL_VERSION -eq 7 ];
	then
		echo "INFO: Creating directory '${SYS_INFO}/usr'." >> "${LOG}"
		MSG=$( mkdir "${SYS_INFO}"/usr 2>&1 )
		check_warning
		
		if [ -d "${SYS_INFO}"/usr ];
		then
			echo "INFO: Creating directory '${SYS_INFO}/usr/lib'." >> "${LOG}"
			MSG=$( mkdir "${SYS_INFO}"/usr/lib 2>&1 )
			check_warning
			
			if [ -d "${SYS_INFO}"/usr/lib ];
			then
				DIR="usr/lib"
				SUB_DIR="tuned"
				copy_dirs
			else
				echo -e "WARNING: Cannot create directory '${SYS_INFO}/usr/lib'. Continuing...\n" >> "${LOG}"
				WARNINGS=1
			fi
		else
			echo -e "WARNING: Cannot create directory '${SYS_INFO}/usr'. Continuing...\n" >> "${LOG}"
			WARNINGS=1
		fi
	fi
}

# Validate files and create a tar.gz of the system_info directory
#	called gather_info_[DATE].tar.gz
tar_files() {
	CURR_FILE="${BASEDIR}/gather_info_${HOSTNAME}_${DATE}.tar.gz"
	
	echo "INFO: Gathering and compressing files into '${CURR_FILE}'." >> "${LOG}"
	MSG=$( tar -zcf "${CURR_FILE}" -C "${BASEDIR}" ./system_info ./gather_info.log ./gather_info.sh 2>&1 )
	check_warning
	
	# Verify that the gather_info tar.gz was created successfully
	if [ -f "${CURR_FILE}" ];
	then
		echo -e "'${CURR_FILE}' was created successfully.\n\nCleaning up '${BASEDIR}/system_info' directory.\n"
		echo -e "'${CURR_FILE}' was created successfully.\nCleaning up '${BASEDIR}/system_info' directory." >> "${LOG}"
		MSG=$( rm -rf "${SYS_INFO}" 2>&1 )
		# Notify the user of any issues encountered
		#	while cleaning up ./system_info directory
		if [ "${MSG}" != "" ];
		then
			echo -e "ERROR:\n------" >> "${LOG}"
			echo -e "$MSG" >> "${LOG}"
			echo "------" >> "${LOG}"
			errors_found
		fi
	else
		echo "ERROR: Cannot create '${CURR_FILE}' from './system_info'. Exiting now..." >> "${LOG}"
		errors_found
		exit 1
	fi
}

# Main gather_info function. Setup and call functions required to
#	gather all of the set info from the system
gather_info() {
	echo -e "\nGathering system information...\n"
	
	initialize
	
	# Gather /proc files
	if [ -d "/proc/" ];
	then
		DIR="proc"
		
		create_new_dir
		
		if [ -d "${SYS_INFO}/proc" ];
		then
			for PROC in ${PROCS};
			do
				FILE=$PROC
				copy_files
			done
		else
			echo -e "WARNING: Cannot create directory '${SYS_INFO}/proc'. Continuing...\n" >> "${LOG}"
			WARNINGS=1
		fi
	else
		echo -e "WARNING: Directory '/proc/' does not exist. Continuing...\n" >> "${LOG}"
		WARNINGS=1
	fi
	
	# Gather /etc files and directories
	if [ -d "/etc/" ];
	then
		DIR="etc"
		
		create_new_dir
		
		if [ -d "${SYS_INFO}/etc" ];
		then
			for ETC_FILE in ${ETC_FILES};
			do
				FILE=$ETC_FILE
				copy_files
			done
			
			for ETC_DIR in ${ETC_DIRS};
			do
				SUB_DIR=$ETC_DIR
				copy_dirs
			done
		else
			echo -e "WARNING: Cannot create directory '${SYS_INFO}/etc'. Continuing...\n" >> "${LOG}"
			WARNINGS=1
		fi
	else
		echo -e "WARNING: Directory '/etc/' does not exist. Continuing...\n" >> "${LOG}"
		WARNINGS=1
	fi
	
	# Gather remaining files
	for ITEM in ${OTHER_FILES}
	do
		FULL_DIR=`echo ${ITEM} | awk -F\: '{ print $1 }'`
		SPLIT_DIRS=${FULL_DIR//// }
		DIR=""
		
		if [ -d "/${FULL_DIR}" ];
		then
			for CURR_DIR in ${SPLIT_DIRS}
			do
				if [ ${DIR} ];
				then
					DIR="${DIR}/${CURR_DIR}"
				else
					DIR="${CURR_DIR}"
				fi
				
				create_new_dir
				
				if [ ];
				then
				if [ ! -d "${SYS_INFO}/${DIR}" ];
				then
					echo "INFO: Creating directory '${DIR}'" >> "${LOG}"
					
					MSG=$( mkdir "${SYS_INFO}/${DIR}" 2>&1 )
					check_warning
				else
					echo -e "${SYS_INFO}/${DIR} exists. Continuing...\n"
				fi
				fi
			done
			
			if [ -d "${SYS_INFO}/${DIR}" ];
			then
				FILES=`echo ${ITEM} | awk -F\: '{ print $2 }' | sed "s;,; ;g"`
				for FILE in ${FILES}
				do
					if [ -f "/${FULL_DIR}/${FILE}" ];
					then
						copy_files
					else
						echo -e "  WARNING: File '/${FULL_DIR}/${FILE}' does not exist. Continuing...\n" >> "${LOG}"
						WARNINGS=1
					fi
				done
			fi
		fi
	done
	
	# Copy output of set commands
	copy_cmds
	
	# Gather tuned profiles
	copy_tuned
	
	# Tar up all of the system info
	tar_files
	
	# If any warnings were found throughout the process, notify the user
	if [ $WARNINGS -eq 1 ];
	then
		warnings_found
	fi
}

# ====================================================================
# SCRIPT START
# ====================================================================
if [ -z "$1" ];
then
	# Verify that this script is being ran as root
	if [[ $EUID -ne 0 ]];
	then
	   echo -e "\nThis script must be run as root\n"
	   exit 1
	fi
	gather_info
else
	while test -n "$1";
	do
		case "$1" in
			# Show usage
			--help|-help|--h|-h)
				show_usage
				break;;
			--version|-version|--v|-v)
				show_version
				break;;
			# Catch invalid parameters
			*)
				echo -e "Invalid parameter: $1\n"
				show_usage
				exit -1
				break;;
		esac
	done
fi

exit 0
