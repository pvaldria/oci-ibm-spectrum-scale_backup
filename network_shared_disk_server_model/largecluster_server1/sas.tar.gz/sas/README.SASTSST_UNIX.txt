NOTE |1| Operating system prerequisite checking utility for Visual Analytics distributed (mmp) installation 
HTTP |1| http://support.sas.com/kb/51276
FILES|1| prc.sh SASENV.va

NOTE |2| Testing UNIX file locking with the lockmenu.c application 
HTTP |2| http://support.sas.com/kb/49074
FILES|2| lockmenu.c lockmenu_rhel lockmenu_aix lockmenu_hp lockmenu_sax lockmenu_sparc 

NOTE |3| Testing Throughput for your SAS 9 File systems: RHEL Linux platforms
HTTP |3| http://support.sas.com/kb/59680
FILES|3| rhel_iotest.sh

NOTE |4| Testing Throughput for your SAS 9 File systems: UNIX and non-RHEL Linux platforms
HTTP |4| http://support.sas.com/kb/51660
FILES|4| iotest.sh 

NOTE |5| Management of single or multi-tiered SAS related services for Unix/Linux deployments 
HTTP |5| http://support.sas.com/kb/58231
FILES|5| SAS_lsm SAS_lsm.cfg-template SAS_lsm_LASR.tar SAS_lsm.pdf

NOTE |6| Gathering performance-related information about RHEL 6 and RHEL 7 environments
HTTP |6| http://support.sas.com/kb/57825
FILES|6| gather_info.sh


NOTE |7| Using the LASRInfo.jar utility to see information about your SAS LASR Analytics Server
HTTP |7| http://support.sas.com/kb/58922.html
FILES|7| LASRInfo.jar

NOTE |8| Discovery, Collect and Deliver (DCD) utility 
HTTP |8| http://support.sas.com/kb/54679
FILES|8| calculate_space_requirements.sh dcd.sh extendables/options.sas extendables/setinit.sas

NOTE |9| Import user defined catalogs from SAS 9.4 into SAS Visual Analytics 8.1
HTTP |9| http://support.sas.com/kb/60136
FILES|9| copyformats.sh

NOTE |10| SAS Network Diagnostic Tool
HTTP |10| http://support.sas.com/kb/59985.html
FILES|10| sndt101.jar

NOTE |11| SAS Memory Diagnostic Tool
HTTP |11| http://support.sas.com/kb/58/947.html
FILES|11| smdt101.jar

NOTE |12| Identifying circular relationships between groups in the SAS® Metadata Server
HTTP |12| http://support.sas.com/kb/60/710.html 
FILES|12| SAS381-2017_SAS_Code.zip

NOTE |13| Using Python Administration Tools in SAS Viya
HTTP |13| http://support.sas.com/kb/60/180.html
FILES|13| CASManagementUtilities.py getServiceMetrics.py getVAReports.py readme.pdf support_utilities.py checkSystemHealth.py getServiceVersions.py getViyaFolders.py refreshTablesInCAS.py
