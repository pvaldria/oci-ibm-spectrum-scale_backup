RC=0
echo "" >> ${STATUSFILE}
echo "" >> ${STATUSFILE}
echo "<<STATUS>> starting collection process for [${LOGTYPE}] logs" | tee -a ${STATUSFILE}
echo "           calculating space requirements for tar source directory [${TARDIR}]" | tee -a ${STATUSFILE}
((SPACE_REQUIRED=0))
while read ITEM 
  do
        if [ -d "${ITEM}" -o -f "${ITEM}" ]
          then  ((SPACE_REQUIRED=SPACE_REQUIRED+`du -s -k "${ITEM}" | awk '{ print $1 }'`))
        fi
  done <${LIST}
case "${OS}" in
  HP-UX)        SPACE_AVAILABLE=`df -k /tmp | grep free | awk '{ print $1 }'`
                ;;
  *)            SPACE_AVAILABLE=`df -k /tmp | tail -1 | awk '{ print $3 }'`
                ;;
esac
if [ "${SPACE_REQUIRED}" -gt "${SPACE_AVAILABLE}" ]
  then  RC=1
        echo "<<ERROR>>  tar directory [${TARDIR}] has [${SPACE_AVAILABLE}] freespace and needs [${SPACE_REQUIRED}]" | tee -a ${STATUSFILE}
fi
exit ${RC}
