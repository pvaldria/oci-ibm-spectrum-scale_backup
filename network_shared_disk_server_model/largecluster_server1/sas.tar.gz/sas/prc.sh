##!/bin/sh

usage ()
{
	echo ""
	echo "INVOCATION: ${PROG} -t <smp|mmp> -c -h"
	echo ""
	echo "WHERE     : REQUIRED  -t is the type of VA deployment (smp = single machine, mmp = distributed grid)"
	echo "            OPTIONAL  -c indicates target validation for a specific component or set of components"
	echo "                      -h displays this help"
	echo ""
	echo "The SASENV.va SAS environment control file [SASENV.va] must reside in the same directory as the program [${PROG}] and contain the following variable definitions and sample values:"
	echo ""
	echo "export BLADE0_HOSTNAME=sasts001"
	echo "export INSTALLER_ID=sas"
	echo "export DEMO_ID=sasdemo"
	echo "export SRV_ID=sassrv"
	echo "export HADOOP_ID=hadoop"
	echo "export LASRADM_ID=lasradm"
	echo "export SAS_GROUP=sas"
	echo "export SASUSER_GROUP=sasusers"
	echo "export HADOOP_GROUP=hadoop"
	echo "export DEPOT_HOME=/mnt/depot"
	echo "export SAS_HOME=/opt/sas/install"
	echo "export SASCONFIG_HOME=/opt/sas/config"
	echo "export THIRDPARTY_HOME=/opt/sas/thirdparty"
	echo "export SASWORK_HOME=/saswork"
	echo "export TKGRID_HOME=/opt/TKGrid_2.1"
	echo "export HPMC_HOME=/opt/webmin"
	echo "export HADOOP_HOME=/hadoop"
	echo ""
	exit 1
}

vue ()
{
	RC=0
	cd ${WDIR}
	if [ ! -f SASENV.va ]
	  then	thrownotification "  << NOTE >> SASENV.va SAS environment variable file needs to exist"
		usage
	  else 	. ./SASENV.va
	fi
	USER=`id -n -u`
	if [ "${USER}" != "root" ]
	  then	thrownotification "  << NOTE >> program [${PROG}] needs to be run by userid [root]"
	fi
	THISHOST=`hostname -s`
	if [ "${BLADE0_HOSTNAME}" != "${THISHOST}" ]
	  then	thrownotification "  << NOTE >> program [${PROG}] needs to be run on BLADE 0 host [${BLADE0_HOSTNAME}]"
	fi
	case ${TYPE} in
	  smp|mmp)	if [ "${TYPE}" = "smp" ]
	  		  then	DOCUMENT="SAS Visual Analytics Non-Distributed Environment Deployment Prerequisites"
				exit
	  		  else	DOCUMENT="SAS Visual Analytics Distributed Environment Deployment Prerequisites"
				SECTION="5.1"
				GRID_HOST_FILE=/etc/gridhosts
				if [ ! -f "${GRID_HOST_FILE}" ] 
		  		  then	thrownotification "  << NOTE:${SECTION} >> GRID host file [${GRID_HOST_FILE}] does not exist." 
		  		  else	GRID_LIST=`cat ${GRID_HOST_FILE} | egrep -v "^#" |  tr '\n' ' '`
					if [ -z "${GRID_LIST}" ]
					  then	thrownotification "  << NOTE:${SECTION} >> GRID host file [${GRID_HOST_FILE}] is empty."
					  else	HEAD_NODE=`head -1 ${GRID_HOST_FILE}`
						if [ "${HEAD_NODE}" != "${BLADE0_HOSTNAME}" ]
						  then	thrownotification "  << NOTE:${SECTION} >> The first entry of the GRID host file [${GRID_HOST_FILE}] needs to be [${BLADE0_HOSTNAME}]"
						fi
					fi
				fi
			fi
			SECTION="5.3.1"
			for GHOST in ${GRID_LIST}
	  		  do
				UMASK=`runcmd "umask" 2>/dev/null`
				if [ $? -ne 0 ]
	  	  		  then	thrownotification "  << NOTE:${SECTION} >> host [${GHOST}] is not accessible via ssh by [root]."
		  		  else	if [ "${UMASK}" != "0022" ]
	  		  	  	  then	thrownotification "  << NOTE:${SECTION} >> umask setting [${UMASK}] needs to be [0022] on host [${GHOST}] for [root]."
					fi
				fi
	  		  done
			;;
	  *)		usage
			;;
	esac
	if [ ${RC} -eq 0 ]
	  then	initialize
		if [ -z "${TARGET}" ]
	  	  then	selinux
		fi
	fi
}

initialize ()
{
	SSH_USERID_LIST="${INSTALLER_ID} ${LASRADM_ID} ${HADOOP_ID}"
	STATUS=passed
	OSVMIN=6.1
	OSARCH=x86_64
	REDHATUPDATES_FILE=/etc/sysconfig/rhn/systemid
	MUP=65536
	MOFD=150000
	PYTHONMIN=2.6
	PYTHONMAX=3.0
	SSHMAXSTARTUPS=1000
	OS_PACKAGE_LIST="nfs-utils nfs-utils-lib gcc-4.4.7-3.el6.x86_64 firefox compat-libstdc++-33 compat-glibc libuuid libSM libXrender fontconfig libstdc++ zlib apr ksh"
	TMPFILE=/tmp/tmpfile.$$
	REPORT=/tmp/report.$$
	echo "VA PRE-REQ READINESS REPORT" | tee ${REPORT}
	echo "---------------------------" | tee -a ${REPORT}
	echo "" | tee -a ${REPORT}
	echo "REFERENCE GUIDE: ${DOCUMENT}" | tee -a ${REPORT}
	echo "" | tee -a ${REPORT}
}

environment ()
{
	genheader "ENVIRONMENT"
	echo "BLADE 0 hostname                       : ${BLADE0_HOSTNAME}" | tee -a ${REPORT}
	echo "BLADE grid list                        : ${GRID_LIST:-not applicable}" | tee -a ${REPORT}
	echo "SAS installation userid                : ${INSTALLER_ID}" | tee -a ${REPORT}
	echo "SAS demo userid                        : ${DEMO_ID}" | tee -a ${REPORT}
	echo "SAS service id                         : ${SRV_ID}" | tee -a ${REPORT}
	echo "SAS install/run group                  : ${SAS_GROUP}" | tee -a ${REPORT}
	echo "SAS user group                         : ${SASUSER_GROUP}" | tee -a ${REPORT}
	echo "SAS software depot directory           : ${DEPOT_HOME}" | tee -a ${REPORT}
	echo "SAS home directory                     : ${SAS_HOME}" | tee -a ${REPORT}
	echo "SAS configuration directory            : ${SASCONFIG_HOME}" | tee -a ${REPORT}
	echo "root directory for third party software: ${THIRDPARTY_HOME}" | tee -a ${REPORT}
	echo "SAS work directory                     : ${SASWORK_HOME}" | tee -a ${REPORT}
	echo "SAS HP node install directory          : ${TKGRID_HOME}" | tee -a ${REPORT}
	echo "SAS HPMC install directory             : ${HPMC_HOME}" | tee -a ${REPORT}
	echo "SAS Hadoop install directory           : ${HADOOP_HOME}" | tee -a ${REPORT}
	echo "" >> ${REPORT}
	echo "" >> ${REPORT}
}

genheader ()
{
	HEADER=${1}
	STATUS=passed
	echo "" | tee -a ${REPORT}
	echo "" | tee -a ${REPORT}
	echo "**********************************************************************************************************" | tee -a ${REPORT}
	echo "SECTION ${SECTION}: ${HEADER}" | tee -a ${REPORT}
	echo "**********************************************************************************************************" | tee -a ${REPORT}
	echo "" | tee -a ${REPORT}
}

thrownotification ()
{
	NOTE="${1}"
	echo "${NOTE}" | tee -a ${REPORT}
	STATUS=failed
 	RC=1
}

genstatus ()
{
	STATUS="${1}"
	echo "" | tee -a ${REPORT}
	if [ "${STATUS}" = "passed" ]
	  then	echo "SUCCESS : evaluation successful" | tee -a ${REPORT}
	  else  echo "NOTES   : evaluation notes taken, potential remediation required" | tee -a ${REPORT}
	fi
}

runcmd ()
{
	CMD=$1
	${SSHCMD} ${GHOST} "${CMD}" 2>/dev/null
}

pam ()
{
	SECTION="4.0"
	genheader "PARTITIONS AMD MOUNT POINTS ACROSS ALL BLADES" 
	for GHOST in ${GRID_LIST}
	  do
		echo "" | tee -a ${REPORT}
	 	echo "SUB-SECTION CHECKING HOST: [${GHOST}]" | tee -a ${REPORT}
		echo "" | tee -a ${REPORT}
		echo "disk report" | tee -a ${REPORT}
		echo "-----------" | tee -a ${REPORT}
		runcmd "df -h" | tee -a ${REPORT}
		echo "" | tee -a ${REPORT}
		echo "mount report" | tee -a ${REPORT}
		echo "------------" | tee -a ${REPORT}
		runcmd "mount" | tee -a ${REPORT}
		echo "" | tee -a ${REPORT}
	  done
}

nosuid ()
{
	SECTION="4.0"
	genheader "SASHOME MOUNT SETTINGS ON BLADE 0 ONLY" 
	mount >${TMPFILE}
	echo "" | tee -a ${REPORT}
	TSAS_HOME=${SAS_HOME}
 	echo "EVALUATE: verify SASHOME [${SAS_HOME}] on BLADE 0 host [${BLADE0_HOSTNAME}] does not contain the option [nosuid]" | tee -a ${REPORT}
	echo "" | tee -a ${REPORT}
	while true
  	  do
		CHECK=`grep "on ${TSAS_HOME} " ${TMPFILE}`
		if [ -z "${CHECK}" ]
	  	  then	TSAS_HOME=${TSAS_HOME%/*}
			if [ -z "${TSAS_HOME}" ]
		  	  then	TSAS_HOME=/
			fi
	  	  else	break
		fi
  	  done
	LIST=`echo ${CHECK} | awk -F\( '{ print $2 }' | sed "s;,; ;g" | sed "s;);;"`
	for ITEM in ${LIST}
  	  do
		if [ "${ITEM}" = "nosuid" ]
	  	  then	thrownotification "  << NOTE:${SECTION}:${BLADE0_HOSTNAME} >> nosuid setting cannot be set on SAS home directory [${SAS_HOME}]"
			break
		fi
  	  done
 	genstatus "${STATUS}"
}
	
operating_system ()
{
	SECTION="5.4"
	genheader "OPERATING SYSTEM VERSION ACROSS ALL BLADES"
	echo "EVALUATE: verify Red Hat operating system version is at or above [${OSVMIN}] and architecture is [${OSARCH}] and is consistent across blades [${GRID_LIST}]" | tee -a ${REPORT}
	echo "" | tee -a ${REPORT}
	for GHOST in ${GRID_LIST}
	  do
		echo "Verifying host [${GHOST}]" | tee -a ${REPORT}
	  	VERSION=`runcmd "head -1 /etc/redhat-release" | awk '{ print $7 }'`
		CHECK=`echo "(${VERSION} >= ${OSVMIN})" | bc -l`
		if [ "${CHECK}" -ne 1 ]
	  	  then	thrownotification "  << NOTE:${SECTION}:${GHOST} >> Red Hat version [${VERSION}] not installed at or above required version [${OSVMIN}]"
	  	  else	CHECK=`runcmd "uname -m"`
			if [ "${CHECK}" != "${OSARCH}" ]
	  	  	  then	thrownotification "  << NOTE:${SECTION}:${GHOST} >> Red Hat architecture [${CHECK}] does not match required [${OSARCH}]" 
			fi	
		fi
		if [ "${GHOST}" = "${BLADE0_HOSTNAME}" ]
 		  then 	VERSION_MASTER=${VERSION}
			OSARCH_MASTER=${CHECK}
		  else	if [ "${VERSION}" != "${VERSION_MASTER}" ]
			  then	thrownotification "  << NOTE:${SECTION}:${GHOST} >> Red Hat version [${VERSION}] does not match master version [${VERSION_MASTER}]"
			fi
			if [ "${CHECK}" != "${OSARCH_MASTER}" ]
			  then	thrownotification "  << NOTE:${SECTION}:${GHOST} >> Red Hat architecture [${CHECK}] does not match master architecture [${OSARCH_MASTER}]"
			fi
		fi
	  done
 	genstatus "${STATUS}"
}

SSH_keys ()
{
	SECTION=5.6.3
	USERID_LIST=${1}
	genheader "SSH KEY VALIDATION FOR PASSWORD-LESS ACCESS ACROSS ALL BLADES" 
	echo "EVALUATE: verify ssh password-less access is created for userids [${USERID_LIST}] across blades [${GRID_LIST}]" | tee -a ${REPORT}
	for USERID in ${USERID_LIST}
          do
		echo "" | tee -a ${REPORT}
		echo "SUB-SECTION VERIFYING USERID: [${USERID}]" | tee -a ${REPORT}
		echo "" | tee -a ${REPORT}
		for GHOST in ${GRID_LIST}
		  do
			echo "Verifying USER [${USERID}] at host [${GHOST}] id_rsa format" | tee -a ${REPORT}
			CHECK=`su - ${USERID} -c '${SSHCMD} ${GHOST} grep -c "BEGIN RSA PRIVATE KEY" ~/.ssh/id_rsa' 2>/dev/null`
			if [ "${CHECK}" -ne 1 ]
        		  then  thrownotification "  << NOTE:${SECTION}:${GHOST} >> userid [${USERID}] does not have proper id_rsa format"
			fi
			for CHOST in ${GRID_LIST}
			  do
				echo "Verifying host [${GHOST}] to host [${CHOST}]" | tee -a ${REPORT}
        			su - ${USERID} -c "${SSHCMD} ${GHOST} ${SSHCMD} ${CHOST} cat /dev/null" >${TMPFILE} 2>&1
        			if [ $? -ne 0 ]
        		  	  then  thrownotification "  << NOTE:${SECTION}:${GHOST} >> userid [${USERID}] does not allow password-less access"
					cat ${TMPFILE}
				fi
			  done
        	  done
	  done
 	genstatus "${STATUS}"
}

sudoers ()
{
	SECTION=5.6.4
	genheader "SUDOER ACCESS FOR HADOOP"
	echo "EVALUATE: verify the userid [${HADOOP_ID}] has proper sudo access across across blades [${GRID_LIST}]" | tee -a ${REPORT}
	echo "" | tee -a ${REPORT}
	for GHOST in ${GRID_LIST}
         do
                echo "Verifying host [${GHOST}]" | tee -a ${REPORT}
		runcmd "grep ${HADOOP_ID} /etc/sudoers" > ${TMPFILE}
        	if [ $? -ne 0 ]
        	  then  thrownotification "  << NOTE:${SECTION}:${GHOST} >> userid [${HADOOP_ID}] does have sudoer access." 
		fi
	  done
 	genstatus "${STATUS}"
}

userids ()
{
	SECTION="5.6.1"
	USERID_LIST="${INSTALLER_ID} ${HADOOP_ID} ${LASRADM_ID} ${DEMO_ID} ${SRV_ID}"
	genheader "USERIDS"
	echo "EVALUATE: verify userids [${USERID_LIST}] have been properly defined across blades [${GRID_LIST}]" | tee -a ${REPORT}
	for USERID in ${USERID_LIST}
	  do	
		echo "" | tee -a ${REPORT}
		echo "SUB-SECTION VERIFYING USERID: [${USERID}]" | tee -a ${REPORT}
		echo "" | tee -a ${REPORT}
		for GHOST in ${GRID_LIST}
	  	  do
			echo "Verifying host [${GHOST}]" | tee -a ${REPORT}
			runcmd "id ${USERID}" > ${TMPFILE}
			USERIDN_LIST=""
			UNCOUNT=`cat ${TMPFILE} | wc -l`
			case ${UNCOUNT} in
			  0)	thrownotification "  << NOTE:${SECTION}:${GHOST} >> userid [${USERID}] does not exist" 
				;;
			  1)	RECORD=`head -1 ${TMPFILE}`
				U_ID=`echo ${RECORD} | awk -F\= '{ print $2 }' | awk -F\( '{ print $1 }'`
				GID=`echo ${RECORD} | awk -F\= '{ print  $3 }' | awk -F\( '{ print $1 }'`
				#HOM=`echo ${RECORD} | awk -F\: '{ print  $6 }'`
				#SHE=`echo ${RECORD} | awk -F\: '{ print  $7 }'`
				if [ "${GHOST}" = "${BLADE0_HOSTNAME}" ]
 		  		  then	UID_MASTER=${U_ID}
					GID_MASTER=${GID}
					#HOM_MASTER=${HOM}
					#SHE_MASTER=${SHE}
		  		  else	if [ "${U_ID}" != "${UID_MASTER}" ]
			  		  then	thrownotification "  << NOTE:${SECTION}:${GHOST} >> userid [${USERID}] uid [${U_ID}] value does not match BLADE 0 value [${UID_MASTER}]"
					fi
		  			if [ "${GID}" != "${GID_MASTER}" ]
			  		  then	thrownotification "  << NOTE:${SECTION}:${GHOST} >> userid [${USERID}] gid [${GID}] value does not match BLADE 0 value [${GID_MASTER}]"
					fi
		  			#if [ "${HOM}" != "${HOM_MASTER}" ]
			  		#then	thrownotification "  << NOTE:${SECTION}:${GHOST} >> userid [${USERID}] home [${HOM}] directory does not match BLADE 0 value [${HOM_MASTER}]"
					#fi
		  			#if [ "${SHE}" != "${SHE_MASTER}" ]
			  		#then	thrownotification "  << NOTE:${SECTION}:${GHOST} >> userid [${USERID}] shell [${SHE}] setting does not match BLADE 0 setting [${SHE_MASTER}]"
					#fi
				fi
					;;
			esac
	  	  done
	  done
	genstatus "${STATUS}"
}

groups ()
{
	SECTION="5.5"
	GROUP_LIST="${SAS_GROUP} ${SASUSER_GROUP} ${HADOOP_GROUP}"
	genheader "GROUPS"
	echo "EVALUATE: verify groups [${GROUP_LIST}] have been properly defined across blades [${GRID_LIST}]" | tee -a ${REPORT}
	for GROUP in ${GROUP_LIST}
	  do	
		echo "" | tee -a ${REPORT}
		echo "SUB-SECTION VERIFYING GROUP: [${GROUP}]" | tee -a ${REPORT}
		echo "" | tee -a ${REPORT}
		for GHOST in ${GRID_LIST}
          	  do
			echo "Verifying host ${GHOST}" | tee -a ${REPORT}
			runcmd "getent group ${GROUP}" > ${TMPFILE}
			GNCOUNT=`grep -c "^${GROUP}:" ${TMPFILE}`
			case ${GNCOUNT} in
			  0)	thrownotification "  << NOTE:${SECTION}:${GHOST} >> group [${GROUP}] does not exist" 
				;;
			  1)	GID=`grep "^${GROUP}:" ${TMPFILE} | awk -F\: '{ print  $3 }'`
				if [ "${GHOST}" = "${BLADE0_HOSTNAME}" ]
 		  		  then 	GID_MASTER=${GID}
		  		  else	if [ "${GID}" != "${GID_MASTER}" ]
			  		  then	thrownotification "  << NOTE:${SECTION}:${GHOST} >> group [${GROUP}] gid [${GID}] value does not match BLADE 0 [${GID_MASTER}]"
					fi
				fi
				;;
			esac
	  	  done
	  done
	genstatus "${STATUS}"
}

hostnames ()
{
	SECTION="5.7.1 "
	genheader "HOSTNAME"
	echo "EVALUATE: verify all hostnames are reachable by IP address, DNS shortname alias, and localhost definition" | tee -a ${REPORT}
	echo "" | tee -a ${REPORT}
	for GHOST in ${GRID_LIST}
          do
                echo "Verifying host [${GHOST}]" | tee -a ${REPORT}
		VERSION=`runcmd "head -1 /etc/redhat-release" | awk '{ print $7 }'`
		if [ "${VERSION}" =  "6.1" ]
		  then	LHOSTNAME=`runcmd "hostname -s"`
		  else	LHOSTNAME=`runcmd "hostname -A"`
		fi
		SHOSTNAME=`runcmd "hostname -s"`
		IP=`runcmd "hostname -i"`
		CHECK=`nslookup ${LHOSTNAME} | grep -c ${IP}`
		if [ "${CHECK}" -eq 0 ]
	  	  then	thrownotification "  << NOTE:${SECTION}:${GHOST} >> cannot lookup ip address [${IP}] via long hostname [${LHOSTNAME}]."
		fi
		CHECK=`nslookup ${IP} | grep -c ${LHOSTNAME}`
		if [ "${CHECK}" -eq 0 ]
	  	  then	thrownotification "    << NOTE:${SECTION}:${GHOST} >> cannot lookup long hostname [${LHOSTNAME}] via ip address [${IP}]."
		fi
		CHECK=`nslookup ${SHOSTNAME} | grep -c ${LHOSTNAME}`
		if [ ${CHECK} -eq 0 ]
	  	  then	thrownotification "    << NOTE:${SECTION}:${GHOST} >> cannot lookup long hostname [${LHOSTNAME}] via alias [${SHOSTNAME}]."
		fi
		runcmd "nslookup localhost >/dev/null 2>&1"
		CHECK=$?
		if [ ${CHECK} -ne 0 ]
	  	  then	thrownotification "    << NOTE:${SECTION}:${GHOST} >> cannot lookup hostname [localhost] via alias [localhost]."
		fi
	  done
 	genstatus "${STATUS}"
}

redhatnetwork ()
{
	SECTION="5.7.2"
	genheader "RED HAT NETWORK UPDATES"
	echo "EVALUATE: verify system registration with RedHat Network for updates per file [${REDHATUPDATES_FILE}] across blades [${GRID_LIST}]" | tee -a ${REPORT}
	echo "" | tee -a ${REPORT}
	for GHOST in ${GRID_LIST}
          do
                echo "Verifying host [${GHOST}]" | tee -a ${REPORT}
		runcmd "ls -lt ${REDHATUPDATES_FILE}" >/dev/null 2>&1 
		if [ $? -ne 0 ]
	  	  then	thrownotification "  << NOTE:${SECTION}:${GHOST} >> system is not registered with the RedHat Network for updates"
		fi
	  done
 	genstatus "${STATUS}"
}

checkownership ()
{
	CHECK=${1}
	CHECK_OWNER=`runcmd "stat -c %U ${CHECK}" | awk '{ print $1 }'`
	CHECK_GROUP=`runcmd "stat -c %G ${CHECK}" | awk '{ print $1 }'`
	CHECK_PERMS=`runcmd "stat -c %a ${CHECK}" | awk '{ print $1 }'`
	if [ "${PERMS}" != "${CHECK_PERMS}" -a "${PERMS}" != "na" ]
	  then	thrownotification "  << NOTE:${SECTION}:${GHOST} >> [${CHECK}] permissions mismatch expected [${PERMS}] found [${CHECK_PERMS}]"
	fi
	if [ "${OWNER}" != "${CHECK_OWNER}" -a "${OWNER}" != "na" ]
	  then	thrownotification "  << NOTE:${SECTION}:${GHOST} >> [${CHECK}] owner mismatch expected [${OWNER}] found [${CHECK_OWNER}]"
	fi
	if [ "${GROUP}" != "${CHECK_GROUP}" -a "${GROUP}" != "na" ]
	  then	thrownotification "  << NOTE:${SECTION}:${GHOST} >> [${CHECK}] group mismatch expected [${GROUP}] found [${CHECK_GROUP}]"
	fi
}

directories ()
{
	SECTION="5.9.1"
	genheader "DIRECTORY LOCATIONS, OWNERSHIP, AND PERMISSIONS"
	echo "EVALUATE: verify directory structure and characteristics (permissions, owner, and group) have been properly defined across blades [${GRID_LIST}]" | tee -a ${REPORT}
 	for GHOST in ${GRID_LIST} 
           do
		echo "" | tee -a ${REPORT}
                echo "SUB-SECTION CHECKING HOST: [${GHOST}]" | tee -a ${REPORT}
                echo "" | tee -a ${REPORT}
		if [ "${GHOST}" = "${BLADE0_HOSTNAME}" ]

		  then	DIRECTORY_LIST="${DEPOT_HOME}:755:${INSTALLER_ID}:${SAS_GROUP} ${SASCONFIG_HOME}:755:${INSTALLER_ID}:${SAS_GROUP} ${SAS_HOME}:755:${INSTALLER_ID}:${SAS_GROUP} ${THIRDPARTY_HOME}:755:${INSTALLER_ID}:${SAS_GROUP} ${SASWORK_HOME}:777:${INSTALLER_ID}:${SAS_GROUP}  ${TKGRID_HOME}:755:${INSTALLER_ID}:${SAS_GROUP}  ${HPMC_HOME}:755:root:root ${HADOOP_HOME}:755:${HADOOP_ID}:${HADOOP_GROUP} /etc/opt/vmware/vfabric:755:${INSTALLER_ID}:${SAS_GROUP}"
		  else	DIRECTORY_LIST="${SASCONFIG_HOME}:755:${INSTALLER_ID}:${SAS_GROUP} ${TKGRID_HOME}:755:${INSTALLER_ID}:${SAS_GROUP} ${HADOOP_HOME}:755:${HADOOP_ID}:${HADOOP_GROUP}"
		fi
 		for RECORD in ${DIRECTORY_LIST}
 	  	  do	
 			DIRECTORY=`echo ${RECORD} | awk -F\: '{ print $1 }'`
 			PERMS=`echo ${RECORD} | awk -F\: '{ print $2 }'`
 			OWNER=`echo ${RECORD} | awk -F\: '{ print $3 }'`
 			GROUP=`echo ${RECORD} | awk -F\: '{ print $4 }'`
 			echo "Verifying directory [${DIRECTORY}]" | tee -a ${REPORT}
 			TEMP=`runcmd "stat -c %F ${DIRECTORY}" 2>/dev/null`
 			CHECK_DIRECTORY=`echo ${TEMP} | awk '{ print $1 }'`
 			if [ "${CHECK_DIRECTORY}" != "directory" ]
 		  	  then	thrownotification "  << NOTE:${SECTION}:${GHOST} >> directory [${DIRECTORY}] does not exist"
 		  	  else	checkownership ${DIRECTORY}
 			fi
 		  done
 	   done
	 genstatus "${STATUS}"
}
	
selinux ()
{
	genheader "SELINUX SECURITY SUBSYSTEM ACROSS ALL BLADES"
	INFILE=/etc/sysconfig/selinux
	echo "EVALUATE: verify SELinux is disabled by setting it to [permissive] or [disabled] in file [${INFILE}] across blades [${GRID_LIST}]" | tee -a ${REPORT}
	echo "" | tee -a ${REPORT}
	for GHOST in ${GRID_LIST}
	  do
		SECTION="5.2"
		echo "Verifying host [${GHOST}]" | tee -a ${REPORT}
		CHECK=`runcmd "getenforce" 2>/dev/null | tr 'A-Z' 'a-z'`
		if [ "${CHECK}" = "enforcing" ]
	  	  then	thrownotification "  << NOTE:${SECTION}:${GHOST} >> SELinux is currently set to [${CHECK}] and should be set to [permissive] or [disabled]"
		  else	if [ -z "${CHECK}" ]
			  then	SECTION="5.3.1"
				thrownotification "  << NOTE:${SECTION}:${GHOST} >> userid: [root] does not allow password-less access from [${BLADE0_HOSTNAME}]."
			fi
		fi
	  done
	genstatus "${STATUS}"
}
	
SSH_maxstartups ()
{
	SECTION="5.10.1"
	genheader "SSH MAX SESSIONS"
	INFILE=/etc/ssh/sshd_config
	echo "EVALUATE: verify SSH maxstartups is set to [${SSHMAXSTARTUPS}] in file [${INFILE}] across blades [${GRID_LIST}]" | tee -a ${REPORT}
	echo "" | tee -a ${REPORT}
	for GHOST in ${GRID_LIST}
	  do
                echo "Verifying host [${GHOST}]" | tee -a ${REPORT}
		CHECK=`runcmd "grep ^MaxStartups  ${INFILE}" | awk '{ print $2 }'`
		if [ "${CHECK}" != "${SSHMAXSTARTUPS}" ]
	  	  then	thrownotification "  << NOTE:${SECTION}:${GHOST} >> Maxstartups is not properly set to [${SSHMAXSTARTUPS}]"
		fi
	  done
	genstatus "${STATUS}"
}
	
cpuspeed ()
{
	SECTION="5.10.2"
	genheader "CPU GOVERNOR"
	INFILE=/etc/sysconfig/cpuspeed
	echo "EVALUATE: verify CPU governor is disabled by setting it to [performance] in file [${INFILE}] across blades [${GRID_LIST}]" | tee -a ${REPORT}
	echo "" | tee -a ${REPORT}
	for GHOST in ${GRID_LIST}
	  do
                echo "Verifying host [${GHOST}]" | tee -a ${REPORT}
		CHECK=`runcmd "grep ^GOVERNOR ${INFILE}" | awk -F\= '{ print $2 }'`
		if [ "${CHECK}" != "performance" ]
	  	  then	thrownotification "  << NOTE:${SECTION}:${GHOST} >> CPU governor is currently set to [${CHECK}] and should be set to [performance]"
		fi
	  done
	genstatus "${STATUS}"
}
	
securitylimits ()
{
	SECTION="5.10.3"
	genheader "USER SECURITY LIMITS"
	echo "EVALUATE: verify hard/soft user limits meet or exceed requirements for maximum user processes [${MUP}] and maximum open file descriptors [${MOFD}] across blades [${GRID_LIST}]" | tee -a ${REPORT}
	for GHOST in ${GRID_LIST}
	  do
		echo "" | tee -a ${REPORT}
                echo "SUB-SECTION CHECKING HOST: [${GHOST}]" | tee -a ${REPORT}
                echo "" | tee -a ${REPORT}
		runcmd "ulimit -H -u -n" >${TMPFILE}
		runcmd "ulimit -u -n" >>${TMPFILE}
		HMUP=`head -1 ${TMPFILE} | awk '{ print $5 }'`
		HMOFD=`head -2 ${TMPFILE} | tail -1 | awk '{ print $4 }'`
		SMUP=`head -3 ${TMPFILE} | tail -1 | awk '{ print $5 }'`
		SMOFD=`head -4 ${TMPFILE} | tail -1 | awk '{ print $4 }'`
 		if [ "${GHOST}" = "${BLADE0_HOSTNAME}" ]
   		  then	HMUP_MASTER=${HMUP}
			HMOFD_MASTER=${HMOFD}
			SMUP_MASTER=${SMUP}
			SMOFD_MASTER=${SMOFD}
		  else	if [ "${HMUP}" != "${HMUP_MASTER}" ]
			  then	thrownotification "  << NOTE:${SECTION}:${GHOST} >> hard setting for maximum user processes [${HMUP}] does not match BLADE 0 [${HMUP_MASTER}]"
			fi
		  	if [ "${HMOFD}" != "${HMOFD_MASTER}" ]
			  then	thrownotification "  << NOTE:${SECTION}:${GHOST} >> hard setting for maximum open file descriptors [${HMOFD}] does not match BLADE 0 [${HMOFD_MASTER}]"
			fi
		  	if [ "${SMUP}" != "${SMUP_MASTER}" ]
			  then	thrownotification "  << NOTE:${SECTION}:${GHOST} >> soft setting for maximum user processes [${SMUP}] does not match BLADE 0 [${SMUP_MASTER}]"
			fi
		  	if [ "${SMOFD}" != "${SMOFD_MASTER}" ]
			  then	thrownotification "  << NOTE:${SECTION}:${GHOST} >> soft setting for maximum open file descriptors [${SMOFD}] does not match BLADE 0 [${SMOFD_MASTER}]"
			fi
		fi	
		echo "Verifying hard setting for maximum user processes" | tee -a ${REPORT}
		if [ "${HMUP}" -lt "${MUP}" ]
	  	  then	thrownotification "  << NOTE:${SECTION}:${GHOST} >> hard setting for maximum user processes [${HMUP}] should be greater than or equal to [${MUP}]"
		fi
		echo "Verifying hard setting for maximum open file descriptors" | tee -a ${REPORT}
		if [ "${HMOFD}" -lt "${MOFD}" ]
	  	  then	thrownotification "  << NOTE:${SECTION}:${GHOST} >> hard setting for maximum open file descriptors [${HMOFD}] should be greater than or equal to [${MOFD}]"
		fi
		echo "Verifying soft setting for maximum user processes" | tee -a ${REPORT}
		if [ "${SMUP}" -lt "${MUP}" ]
	  	  then	thrownotification "  << NOTE:${SECTION}:${GHOST} >> soft setting for maximum user processes [${SMUP}] should be greater than or equal to [${MUP}]"
		fi
		echo "Verifying soft setting for maximum open file descriptors" | tee -a ${REPORT}
		if [ "${SMOFD}" -lt "${MOFD}" ]
	  	  then	thrownotification "  << NOTE:${SECTION}:${GHOST} >> soft setting for maximum open file descriptors [${SMOFD}] should be greater than or equal to [${MOFD}]"
		fi
	  done
	genstatus "${STATUS}"
}

firewall ()
{
	SECTION="5.10.4"
	genheader "FIREWALL"
	echo "EVALUATE: verify iptables firewall between hosts is turned off across blades [${GRID_LIST}]" | tee -a ${REPORT}
	for GHOST in ${GRID_LIST}
	  do
		echo "" | tee -a ${REPORT}
                echo "SUB-SECTION CHECKING HOST: [${GHOST}]" | tee -a ${REPORT}
                echo "" | tee -a ${REPORT}
		for TABLE in iptables ip6tables
		  do
			echo "Verifying table ${TABLE}" | tee -a ${REPORT}
			for ITEM in `runcmd "/sbin/chkconfig --list ${TABLE}" | sed "s;^${TABLE};;"`
			  do
				case "${ITEM}" in
				  *:on)	LEVEL=`echo ${ITEM} | awk -F\: '{ print $1 }'`
					thrownotification "  << NOTE:${SECTION}:${GHOST} >> firewall is turned on for table [${TABLE}] level [${LEVEL}]"
					;;
				  *)	;;
				esac
			  done
		  done
	  done
	genstatus "${STATUS}"
}

atdaemon ()
{
	SECTION="5.11.2.6"
	genheader "AT DAEMON"
	echo "EVALUATE: verify at daemon is available for users across blades [${GRID_LIST}]" | tee -a ${REPORT}
	echo "" | tee -a ${REPORT}
	for GHOST in ${GRID_LIST}
	  do
                echo "Verifying host [${GHOST}]" | tee -a ${REPORT}
		runcmd "service atd status" >${TMPFILE}
 		CHECK=`grep -c "is running...\$" ${TMPFILE}`
 		if [ ${CHECK} -eq 0 ]
 		  then	thrownotification "  << NOTE:${SECTION}:${GHOST} >> at daemon is not running"
		fi
	  done
	genstatus "${STATUS}"
}

cronready ()
{
	SECTION="5.10.5"
	genheader "CRON SCHEDULER"
	echo "EVALUATE: verify cron is available for users [${INSTALLER_ID} ${LASRADM_ID}] across blades [${GRID_LIST}]" | tee -a ${REPORT}
	echo "" | tee -a ${REPORT}
	for GHOST in ${GRID_LIST}
	  do
                echo "" | tee -a ${REPORT}
                echo "SUB-SECTION CHECKING HOST: [${GHOST}]" | tee -a ${REPORT}
                echo "" | tee -a ${REPORT}
		for USER_ID in ${INSTALLER_ID} ${LASRADM_ID}
		  do
			echo "Verifying userid ${USER_ID}" | tee -a ${REPORT}
			CHECK=`runcmd "su - ${USER_ID} -c \"crontab -l 2>&1\" | grep "^You""`
			if [ "${CHECK}" ]
			  then	thrownotification "  << NOTE:${SECTION}:${GHOST} >> cron is not allowed for user [${USER_ID}]"
echo x${CHECK}x
			fi
		  done
	  done
	genstatus "${STATUS}"
}

swpackages ()
{
	SECTION=${1}
	LIST="${2}"
	PACKAGE_LIST="${3}"
	genheader "SOFTWARE PACKAGES"
	echo "EVALUATE: verify software packages [${PACKAGE_LIST}] are installed at proper levels across blades [${LIST}]" | tee -a ${REPORT}
	for PACKAGE in ${PACKAGE_LIST}
	  do
		echo "" | tee -a ${REPORT}
                echo "SUB-SECTION CHECKING PACKAGE: [${PACKAGE}]" | tee -a ${REPORT}
                echo "" | tee -a ${REPORT}
		for GHOST in ${LIST}
	  	  do	
			echo "Verifying host [${GHOST}]" | tee -a ${REPORT}
			CPACKAGE=`runcmd "rpm -qa | grep \"^${PACKAGE}\""`
			if [ -z "${CPACKAGE}" ]
			  then	thrownotification "  << NOTE:${SECTION}:${GHOST} >> package [${PACKAGE}] is not installed"
			  	if [ "${GHOST}" = "${BLADE0_HOSTNAME}" ]
 		  	  	  then 	PACKAGE_MASTER=${CPACKAGE}
		  	  	  else	if [ "${CPACKAGE}" != "${PACKAGE_MASTER}" ]
				  	  then	thrownotification "  << NOTE:${SECTION}:${GHOST} >> package [${CPACKAGE}] does not match master version [${PACKAGE_MASTER}]"
					fi
				fi
			fi
	  	  done
	  done
 	genstatus "${STATUS}"
}
	
X11 ()
{
	SECTION="5.11.1.4"
	genheader "Xll 32 AND 64 BIT SOFTWARE PACKAGES"
	PACKAGE_LIST="libXext libXp libXtst"
	echo "EVALUATE: verify [${PACKAGE_LIST}] 32 and 64 bit software packages are installed across blades [${GRID_LIST}]" | tee -a ${REPORT}
	for PACKAGE in ${PACKAGE_LIST}
	  do	
		echo "" | tee -a ${REPORT}
                echo "SUB-SECTION CHECKING PACKAGE: [${PACKAGE}]" | tee -a ${REPORT}
                echo ""
		for GHOST in ${GRID_LIST}
	  	  do
			echo "Verifying host [${GHOST}]" | tee -a ${REPORT}
			CHECK32=`runcmd "rpm -qa ${PACKAGE} | grep i686\$"`
			CHECK64=`runcmd "rpm -qa ${PACKAGE} | grep x86_64\$"`
			LRC=0
			if [ -z "${CHECK32}" ]
			  then	thrownotification "  << NOTE:${SECTION}:${GHOST} >> package [${PACKAGE} 32 bit] is not installed"
				LRC=1
			fi
			if [ -z "${CHECK64}" ]
			  then	thrownotification "  << NOTE:${SECTION}:${GHOST} >> package [${PACKAGE} 64 bit] is not installed"
				LRC=1
			fi
			if [ ${LRC} -eq 0 ]
			  then	if [ "${GHOST}" = "${BLADE0_HOSTNAME}" ]
 		  	  	  then 	PACKAGE32_MASTER=${CHECK32}
 		  	  		PACKAGE64_MASTER=${CHECK64}
		  	  	  else	if [ "${CHECK32}" != "${PACKAGE32_MASTER}" ]
				  	  then	thrownotification "  << NOTE:${SECTION}:${GHOST} >> package [${PACKAGE}] does not match BLADE 0 [${PACKAGE32_MASTER}]"
					fi
		  	  		if [ "${CHECK64}" != "${PACKAGE64_MASTER}" ]
				  	  then	thrownotification "  << NOTE:${SECTION}:${GHOST} >> package [${PACKAGE}] does not match BLADE 0 [${PACKAGE64_MASTER}]"
					fi
				fi
			fi
		  done
	  done
 	genstatus "${STATUS}"
}
	
python ()
{

	SECTION="5.11.1.3"
	genheader "PYTHON SOFTWARE PACKAGE"
	PACKAGE=python
	echo "EVALUATE: verify [${PACKAGE}] software package is installed at the proper level [between ${PYTHONMIN} and ${PYTHONMAX}] on host [${BLADE0_HOSTNAME}]" | tee -a ${REPORT}
	echo "" | tee -a ${REPORT}
	CHECK=`rpm -q ${PACKAGE}`
		if [ $? -ne 0 ]
		  then	thrownotification "  << NOTE:${SECTION}:${BLADE0_HOSTNAME} >> package [${PACKAGE}] not installed" 
		  else	VERSION=`echo ${CHECK} | awk -F\- '{ print $2 }' | awk -F\. '{ print $1"."$2 }'`
			VCHECK=`echo "(${PYTHONMIN} <= ${VERSION} && ${VERSION} <= ${PYTHONMAX})" | bc -l`
			if [ "${VCHECK}" -ne 1 ]
		  	  then	thrownotification "  << NOTE:${SECTION}:${BLADE0_HOSTNAME} >> package [${CHECK}] not installed at the correct version [between ${PYTHONMIN} and ${PYTHONMAX}]"
			fi	
		fi
 	genstatus "${STATUS}"
}
	
jdk ()
{
	SECTION="5.11.1.2"
	genheader "JDK SOFTWARE PACKAGE"
	PACKAGE="jdk"
	runcmd "java -version 2>&1" >${TMPFILE}
	TEMP=`grep "^java version" ${TMPFILE} | awk '{ print $3 }' | sed "s;\";;g"`
	PACKAGE_MASTER=${TEMP}
	echo "EVALUATE: verify [${PACKAGE}] software package is installed at version [${PACKAGE_MASTER}] across blades [${GRID_LIST}]" | tee -a ${REPORT}
	echo "" | tee -a ${REPORT}
	for GHOST in ${GRID_LIST}
	  do
                echo "Verifying host [${GHOST}]" | tee -a ${REPORT}
		runcmd "java -version 2>&1" >${TMPFILE}
		PACKAGE=`grep "^java version" ${TMPFILE} | awk '{ print $3 }' | sed "s;\";;g"`
		if [ "${PACKAGE}" != "${PACKAGE_MASTER}" ]
		  then	thrownotification "  << NOTE:${SECTION}:${GHOST} >> package [${PACKAGE}] does not match BLADE 0 [${PACKAGE_MASTER}]"
		fi
	  done
 	genstatus "${STATUS}"
}
	
cleanup ()
{
	rm -f ${TMPFILE} >/dev/null 2>&1
	if [ ${RC} -eq 1 ]
  	  then	echo ""
		echo ""
		echo "******************************************************************"
		echo "NOTE    : one or more of the pre-req checks requires review       "
		echo "******************************************************************"
 	 else	echo ""
		echo ""
		echo "**********************************************************"
		echo "SUCCESS : all of the pre-req checks have passed evaluation"
		echo "**********************************************************"
	fi
	echo ""
	echo ""
	echo "The full VA pre-req check report can be found in: ${REPORT}"
}

target ()
{
	while true
	  do
		echo ""
		echo ""
		echo "<ACTION REQUIRED> Please select a component to verify"
		echo ""
		echo "1.  SASHOME mount settings"
		echo "2.  list partions and mount points"
		echo "3.  operating system version and architecture"
		echo "4.  groups have been properly defined"
		echo "5.  userids have been properly defined"
		echo "6.  ssh key validation for password-less access"
		echo "7.  hadoop userid has proper sudo access"
		echo "8.  hostnames are reachable by IP address and DNS shortname alias"
		echo "9.  directory structure and characteristics (permissions, owner, and group) have been properly defined"
		echo "10. SSH maxstartups is set correctly"
		echo "11. CPU governor is disabled"
		echo "12. hard/soft user limits meet or exceed requirements for maximum user processes and maximum open file descriptors"
		echo "13. iptables firewall between hosts is turned off"
		echo "14. cron is available for SAS installer and LASR administrator users"
		echo "15. software packages are installed at proper levels"
		echo "16. at daemon is available for users"
		echo "q   exit"
		echo ""
		echo -n "<<RESPONSE>> "
		read ANSWER
		case "${ANSWER}" in
		  1)	nosuid
			;;	
		  2)	pam
			;;	
		  3)	operating_system
			;;
		  4)	groups
			;;	
		  5)	userids
			;;	
		  6)	SSH_keys "${INSTALLER_ID} ${LASRADM_ID} ${HADOOP_ID}"
			;;	
		  7)	sudoers
			;;	
		  8)	hostnames
			;;	
		  9)	directories
			;;	
		  10)	SSH_maxstartups
			;;	
		  11)	cpuspeed
			;;	
		  12)	securitylimits
			;;	
		  13)	firewall
			;;	
		  14)	cronready
			;;	
		  15)	swpackages 5.11.1.1 "${GRID_LIST}" "${OS_PACKAGE_LIST}"
			swpackages 5.11.1.2 "${GRID_LIST}" "numactl"
			swpackages 5.11.2.5 "${BLADE0_HOSTNAME}" "perl-Net-SSLeay"
			jdk
			python
			X11		
			;;	
		  16)	atdaemon
			;;	
17) selinux
;;
		  q)	return
			;;
		  *)	echo "Not a valid option"
			;;
		esac
		echo ""
		echo ""
	  done
}

# main
WDIR=${0%/*}
PROG=${0#*/}
SSHCMD="ssh -o StrictHostKeyChecking=no -o PasswordAuthentication=no" 
while getopts "t:ch" opt 
  do
        case $opt in
          t)    TYPE=${OPTARG}
		;;
	  c)	TARGET=true
		;;
	  h)	usage
		;;
	  *)	;;
	esac
  done
vue
if [ ${RC} -eq 0 ]
  then	environment
	if [ "${TARGET}" ]
	  then	target
  	  else	nosuid
  		pam
  		operating_system
   		groups
 		userids
		SSH_keys "${INSTALLER_ID} ${LASRADM_ID} ${HADOOP_ID}"
		sudoers
		hostnames
		redhatnetwork
 		directories
		SSH_maxstartups
		cpuspeed
		securitylimits
		firewall
		cronready
		swpackages 5.11.1.1 "${GRID_LIST}" "${OS_PACKAGE_LIST}"
		swpackages 5.11.1.2 "${GRID_LIST}" "numactl"
		jdk
		python
		X11
		swpackages 5.11.2.5 "${BLADE0_HOSTNAME}" "perl-Net-SSLeay"
		atdaemon
	fi
	cleanup
fi
exit ${RC}
