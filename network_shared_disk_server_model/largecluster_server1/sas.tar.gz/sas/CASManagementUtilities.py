#!/usr/bin/env python
#
# CASManagementUtilities.py
#
# Usage
#
#   CASManagementUtilities.py [-h] [-user USER] [-password PASSWORD]
#                             [-debug] [-nologging]
#
#       optional arguments:
#           -h, --help          show this help message and exit
#           -user USER          user id to connect with
#           -password PASSWORD  password used to connect with
#           -listservers        lists all CAS servers defined
#           -listcaslibs        lists all caslibs defined
#           -listtables         lists all CAS tables defined
#           -debug              prints useful debug information
#           -nologging          prevents any log messages from being displayed
#           -prettyprint        prints a tabular format of a given service's
#                               metrics
#
# Return Codes
#
# 0            - Success
# ENOENT       - No such file or directory
# ESRCH        - No such process
# EPERM        - Operation not permitted
# ENXIO        - No such device or address
# ECONNREFUSED - Connection refused
# ?            - Any return from subprocess.Popen()

import argparse
import errno
import getpass
import logging
import support_utilities as s_u
import sys
import urllib2

# Create Logger
logger = logging.getLogger(__name__)

# Make sure Pyton 2 is being used
if sys.version_info[0] >= 3:
    raise AssertionError('This program runs under Python 2')


def main():

    # Parse the command line
    parser = argparse.ArgumentParser(description='Exercises various admin \
                                     tasks with CAS')
    parser.add_argument('-user', help='user id to connect with')
    parser.add_argument('-password', help='password used to connect with')
    parser.add_argument('-listservers', action='store_true',
                        help='lists all CAS servers defined')
    parser.add_argument('-listcaslibs', action='store_true',
                        help='lists all caslibs defined')
    parser.add_argument('-listtables', action='store_true',
                        help='lists all CAS tables defined')
    parser.add_argument('-listperms', action='store_true',
                        help='lists CAS ACLs for the given artifacts')
    parser.add_argument('-tree', action='store_true',
                        help='lists CAS servers, caslibs, and tables in a \
                        tree view')
    parser.add_argument('-d', '--debug', action='store_const',
                        dest='loglevel', const=logging.DEBUG,
                        default=logging.WARNING,
                        help='prints useful debug information')
    parser.add_argument('-v', '--verbose', action='store_const',
                        dest='loglevel', const=logging.INFO,
                        help='prints verbose information')
    parser.add_argument('-nologging', action='store_true',
                        help='prevents any log messages from being displayed')
    args = parser.parse_args()

    # Set the logging configuration
    format = '%(levelname)s: %(asctime)-15s %(message)s'
    logging.basicConfig(level=args.loglevel, format=format)

    # Turn off all logging if the user desires
    if args.nologging:
        logger.disabled = True

    # DEBUG
    logger.debug('Command line arguments - %s', str(args))

    # Assorted constants
    SASLOGON = 'SASLogon/oauth/token'
    CASMGMT = 'casManagement'
    SERVERS = 'servers'

    # Check to see if the user has asked for something
    if ((not args.listservers) and
       (not args.listcaslibs) and
       (not args.listtables) and
       (not args.tree)):

        # Inform the user they must specify a command and error out
        cmderr = 'One command option, e.g. -listservers, must be specified.'
        logger.error('%s\n', cmderr)
        parser.print_help()
        print('\n')
        return errno.EPERM

    # Let the user know things are progressing
    print('Starting analysis of this deployment.\n')

    # Verify CSQ exists on the system
    if not s_u.isSystemValid():
        return errno.ENOENT

    # Verify Consul is active
    consul_status = s_u.validateConsul()
    if not consul_status:
        return consul_status

    # Determine a valid HTTP system to talk to
    httpd_host, httpd_port = s_u.getHTTPDHostAndPort()

    # If no system is found, abort the application
    if (str(httpd_host) is None) or (str(httpd_port) is None):
        return errno.ENXIO

    logger.debug('httpd host is %s', httpd_host)
    logger.debug('httpd port is %s', httpd_port)

    # Deterime the username
    if not args.user:
        logger.debug('Requesting username')
        print('Please enter the credentials you wish to connect with.\n')
        user = raw_input('Username: ')
    else:
        logger.debug('username passed via command line')
        user = args.user

    # Determine the password for the given user
    if not args.password:
        logger.debug('Requesting password')
        passwd = getpass.getpass('Password for %s:' % user)
    else:
        logger.debug('password passed via command line')
        passwd = args.password

    logger.info('Credentials obtained.')

    # Obtain the auth token
    sl_url = 'http://%s:%s/%s' % (httpd_host, httpd_port, SASLOGON)
    rc, auth_header = s_u.getAuthToken(sl_url, user, passwd)

    # Was the auth token obtained? If not, exit
    if ((rc != s_u.SUCCESS) or (auth_header is None)):
        return rc

    # If requested, list the CAS servers
    if args.listservers:

        # Build the URL for the servers endpoint
        item_url = 'http://%s:%s/%s/%s' % (httpd_host, httpd_port,
                                           CASMGMT, SERVERS)
        logger.info('url is %s', item_url)

        # Obtain the list of servers
        rc, servers = s_u.listServers(item_url, auth_header)

        # Was the lists of servers obtainable?
        if ((rc != s_u.SUCCESS) or (servers is None)):
            logger.critical('Could not obtain list of servers.')
            print('Program aborting.')
            return rc

        # Report how many servers were found
        print('\nThere are %s CAS server(s) in this deployment.\n' %
              len(servers))

        # For each server found, enumerate its essential values
        for crnt in servers:
            print('\tName:      %s' % crnt['name'])
            print('\tHostname:  %s' % crnt['host'])
            print('\tPort:      %s' % crnt['port'])
            print('\tREST Port: %s' % crnt['restPort'])
            print('\n')

    # If requested, list the caslibs
    if args.listcaslibs:

        # Build the base URL as the final endpoint will have to be computed
        item_url = 'http://%s:%s/%s/%s' % (httpd_host, httpd_port,
                                           CASMGMT, SERVERS)
        logger.info('base url is %s', item_url)

        # Obtain the list of caslibs
        rc = s_u.listLibraries(item_url, auth_header)

        # Was the lists of caslibs obtainable?
        if rc != s_u.SUCCESS:
            logger.critical('Could not obtain the list of caslibs.')
            return rc

    # if requested, list the CAS tables
    if args.listtables:

        # Build the base URL as the final endpoint will have to be computed
        item_url = 'http://%s:%s/%s/%s' % (httpd_host, httpd_port,
                                           CASMGMT, SERVERS)
        logger.info('base url is %s', item_url)

        # Obtain the list of tables
        rc = s_u.listTables(item_url, auth_header)

        # Was the lists of tables obtainable?
        if rc != s_u.SUCCESS:
            logger.critical('Could not obtain list of CAS tables.')
            print('Program aborting.')
            return rc

    # If requested, list all CAS artifacts in a tree view
    if args.tree:

        # Build the base URL as the final endpoint will have to be computed
        item_url = 'http://%s:%s/%s/%s' % (httpd_host, httpd_port,
                                           CASMGMT, SERVERS)
        logger.info('base url is %s', item_url)

        # Obtain the list of artifacts
        rc = s_u.displayTree(item_url, auth_header)

        # Was the list of artifacts obtainable?
        if rc != s_u.SUCCESS:
            logger.critical('Could not obtain list of CAS artifacts.')
            print('\nApplication completed with errors. Exiting...')
            return rc

    print('\nApplication completed successfully. Exiting...')

# Begin program
if __name__ == '__main__':
    sys.exit(main())
