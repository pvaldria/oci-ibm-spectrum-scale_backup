import codecs
import errno
import json
import logging
import os
import socket
import subprocess
import sys
import urllib
import urllib2

# Constants
CSQ = '/opt/sas/viya/home/bin/sas-csq'
CONSUL_CMD_ARG = 'consul-status'
SERVICE_CMD_TAG = '--service'
ALL_NODES_TAG = '--allnodes'
LIST_CMD_ARG = 'list-services'
INFO_CMD_ARG = 'service-info'
SUCCESS = 0
tab = '    '

# If the application was invokved with -listperms, make note
if '-listperms' in sys.argv:
    listperms = True
else:
    listperms = False

# Make sure when redirecting output to a file or dealing with artifacts with
# uncoide names, everything is processed correctly
reload(sys)
sys.stdout = codecs.getwriter('utf-8')(sys.stdout)
sys.setdefaultencoding('utf-8')


def launchProcess(cmd):
    """
    Launches a process returns the output and any errors
    """
    try:

        # DEBUG
        logger.debug('command and arguments to run: %s', str(cmd))

        # Try to launch the requested command
        proc = subprocess.Popen(cmd,
                                shell=False,
                                stdin=None,
                                stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE)

        # Assign stdout and stderr
        lp_stdout, lp_stderr = proc.communicate()

        # If an error occurred, log the fact and raise the error up the stack
        if proc.returncode != 0:
            logger.error(lp_stderr)
            raise Exception(lp_stdout, lp_stderr)

        # The command was successful so return stdout and stderr
        else:
            return lp_stdout, lp_stderr

    # Handle any exception and return stderr
    except Exception as lpE:
        logger.error("%s failed: %s" % (' '.join(cmd), str(lpE)))
        return None, str(lpE)


def validateHostandPort(host, port):
    """
    Validates the specified host and port
    """

    # Validate the host and port are available
    try:

        # Attempt to open a connection to the host via this port
        tmp_socket = socket.socket()
        logger.debug('attempting socket creation - %s on %s:%s',
                     (str(tmp_socket)), host, port)
        tmp_socket.connect((host, port))
        return True

    except Exception as sockE:

        # log and report back to the user prior to returning
        logger.critical('%s:%s - %s', host, port, sockE)
        print('The specified system (%s, %s) is not reachable.' % (host, port))
        return False

    finally:

        # Either way, close the socket
        if 'tmp_socket' in locals():
            logger.debug('Closing %s.', str(tmp_socket))
            tmp_socket.close()


def validateConsul():
    """
    Validates whether Consul is up and running
    """
    # Verify that consul is running
    csstat_out, csstat_err =\
        launchProcess([CSQ, CONSUL_CMD_ARG])

    # Any errors returned? If so, log and exit
    if (len(csstat_err) > 0) and ('error' in csstat_err):
        print('SAS Viya Consul appears to be down.')
        print('Program aborting.')
        logger.critical('Consul is not available - %s', csstat_out)
        return errno.ESRCH

    # Consul is available
    else:
        logger.debug('Consul is available.')
        return True


def isSystemValid():
    """
    Verifies the system has SAS Viya software present
    """
    # Verify CSQ exists on the system
    if not os.path.exists(CSQ):
        print('%s not found. Is SAS Viya deployed on this system?' % CSQ)
        logger.critical('%s not found.', CSQ)
        return False

    # This is a SAS Viya deployed system
    else:
        logger.debug('This is a SAS Viya deployed system.')
        return True


def getHTTPDHostAndPort():
    """
    Finds a validate HTTPD host and port and returns them to the user
    """
    # Find all machines with httpd in order to talk to SASLogon
    httpd_out, httpd_err =\
        launchProcess([CSQ, INFO_CMD_ARG, ALL_NODES_TAG,
                       SERVICE_CMD_TAG, 'httpd'])

    # Any errors? If so, log, report, and exit
    if (len(httpd_err) > 0) and ('error' in httpd_err):
        print('Unable to execute %s.' % CSQ)
        print('Program Aborting.')
        logger.critical(httpd_err)
        return None, None

    # Take the output and convert to json for manipulation
    parsed_httpout = json.loads(httpd_out)

    # Assume there isn't a valid httpd system
    found_valid_httpd = False

    # loop through the json, looking for a valid host and port
    for system in parsed_httpout:

        # IF we find a valid system, set the host and port and move on
        if validateHostandPort(system['Address'], system['ServicePort']):
            found_valid_httpd = True
            httpd_host = socket.getfqdn(system['Address'])
            httpd_port = system['ServicePort']
            logger.debug('Valid httpd system found.')
            break

    # If there are no valid systems, inform the user and bail
    if not found_valid_httpd:
        logger.critical('No valid HTTPD system found.')
        print('No available systems to access.')
        print('Program Aborting')
        return None, None

    # Valid HTTPD system found
    else:
        return httpd_host, httpd_port


def basic_authorization(user, password):
    """
    Base64 encodes the userid and password in the request auth header
    """

    # Encode user:passwod in base64 for obfusication
    s = '%s:%s' % (user, password)
    return 'Basic %s' % s.encode('base64').rstrip()


def getAuthToken(url, user, password):
    """
    Obtains a SAS Auth bearer token and returns it to the caller
    """

    # Build the url to connect with and the information to send
    sl_url = url
    logger.debug('url to use: %s', sl_url)
    sl_data = 'grant_type=password&username=%s&password=%s' % (user, password)
    logger.debug('asking for a grant type for user (%s) with password', user)

    # Obtain an authentication token from the logon service via user/pass
    try:

        sl_auth = basic_authorization('sas.ec', '')
        sl_headers = {'Accept': 'application/json',
                      'Content-Type': 'application/x-www-form-urlencoded',
                      'Authorization': sl_auth}
        sl_req = urllib2.Request(sl_url, headers=sl_headers, data=sl_data)

        # DEBUG
        logger.debug('request is %s', sl_req)

        # Now open the connection and read the response
        sl_response = urllib2.urlopen(sl_req)
        logger.debug('response is %s', sl_response)
        sl_read_response = sl_response.read()
        logger.debug('response read successfully')

        # Parse the response to get auth token
        jdata = json.loads(sl_read_response)
        auth_header = " bearer " + jdata["access_token"]

        # Close the connection
        sl_response.close()

        logger.debug('auth token obtained successfully')
        logger.info('Connection to the SAS Logon service was successful.')

        return SUCCESS, auth_header

    except Exception as authE:

        # Close the connection if it was opened
        if 'sl_response' in locals():
            logger.debug('Closing the response handle %s', sl_response)
            sl_response.close()

        # Log what happened and inform the user
        logger.critical(authE)
        print('Cannot obtain authentication token as %s was returned.' % authE)
        print('Program aborting.')
        return errno.ECONNREFUSED, None


def getCASACL(url, token):
    """
    Returns the ACL list for the given artifact
    """

    try:

        # Query data
        query_data = {'listType': 'all'}
        encoded_query = urllib.urlencode(query_data)

        # Make the request with the appropriate parameters
        # item_req = urllib2.Request(url, query_data)
        full_url = '%s/?%s' % (url, encoded_query)
        item_req = urllib2.Request(full_url)
        item_req.add_header('Authorization', token)
        item_req.add_header('Accept', 'application/vnd.sas.collection+json')
        item_req.add_header('Response Content Type',
                            'application/vnd.sas.collection+json')
        # item_req.get_method = lambda: 'GET'
        item_response = urllib2.urlopen(item_req)
        item_read_code = item_response.getcode()

        # Read the response and load it into json for processing
        read_item_response = item_response.read()
        dumped_response = json.loads(read_item_response)

        # Close the response
        item_response.close()

    except urllib2.HTTPError, error:

        # Close the connection if it was opened
        if 'item_response' in locals():
            logger.debug('Closing the response handle %s', item_response)
            item_response.close()

        # Log what happened and inform the user
        print('Cannot connect to SAS CAS Access Management'),
        contents = error.read()
        dumped_contents = json.loads(contents)
        logger.warning('HTTP Status Code: %s',
                       dumped_contents['httpStatusCode'])
        logger.warning(dumped_contents['message'])
        return errno.ECONNREFUSED, None, None

    # All good so return the ACLs and how many there are
    return SUCCESS, dumped_response['items'], dumped_response['count']


def listServers(url, token):
    """
    Lists all available CAS serevers in a deployment
    """

    try:

        # Make the request with the appropriate parameters
        item_req = urllib2.Request(url)
        item_req.add_header('Authorization', token)
        item_req.add_header('Response Content Type',
                            'application/vnd.sas.collection+json')
        item_response = urllib2.urlopen(item_req)
        item_read_code = item_response.getcode()

        # Read the response and load it into json for processing
        read_item_response = item_response.read()
        dumped_response = json.loads(read_item_response)

        # Close the response
        item_response.close()

    except Exception as cmE:

        # Close the connection if it was opened
        if 'item_response' in locals():
            logger.debug('Closing the response handle %s', item_response)
            item_response.close()

        # Log what happened and inform the user
        logger.critical(cmE)
        print('Cannot connect to SAS CAS Management as %s was returned.' %
              cmE)
        return errno.ECONNREFUSED, None

    # All good so return the collection of servers
    return SUCCESS, dumped_response['items']


def getServerLibraries(url, token):
    """
    Obtains the list of a specific server's caslibs
    """

    try:

        # Open the connection to CAS Management, get the list, and close
        item_req = urllib2.Request(url)
        item_req.add_header('Authorization', token)
        item_req.add_header('Response Content Type',
                            'application/vnd.sas.collection+json')
        item_response = urllib2.urlopen(item_req)
        item_read_code = item_response.getcode()
        read_item_response = item_response.read()
        dumped_response = json.loads(read_item_response)
        item_response.close()

    except Exception as cmE:

        # Close the connection if it was opened
        if 'item_response' in locals():
            logger.debug('Closing the response handle %s', item_response)
            item_response.close()

        # Log what happened and inform the user
        logger.critical(cmE)
        print('Cannot connect to SAS CAS Management as %s was returned.' %
              cmE)
        return errno.ECONNREFUSED, None

    # All good so return the collection of caslibs in this server
    return SUCCESS, dumped_response['items']


def listLibraries(url, token):
    """
    Lists all available caslibs in a deployment
    """

    LIBRARIES = 'caslibs'

    # Obtain the list of servers first
    srvrc, servers = listServers(url, token)

    # Was the lists of servers obtainable?
    if ((srvrc != SUCCESS) or (servers is None)):
        logger.critical('Could not obtain list of servers.')
        print('Program aborting.')
        return rc, None

    # Yes, so loop through them and request libraries
    for crnt in servers:

        # Build the url for this server
        srv_url = '%s/%s/%s' % (url, crnt['name'], LIBRARIES)
        logger.info('server url is %s', srv_url)

        # Get the caslibs for the current server
        lrc, libraries = getServerLibraries(srv_url, token)

        # Was the lists of servers obtainable?
        if ((lrc != SUCCESS) or (libraries is None)):
            logger.critical('Could not obtain list of libraries for server',
                            '%s.', crnt['name'])
            print('Program aborting.')
            return lrc

        # Display the total number of caslibs found
        print('\nCAS Server %s has %s caslibs defined.\n' %
              (crnt['name'], len(libraries)))

        # Loop through the libraries, detailing specific information
        for lib in libraries:
            print('%sName:             %s' % (tab, lib['name']))
            print('%sType:             %s' % (tab, lib['type']))

            # The description is optional so try and display it
            try:
                print('%sDescription:      %s' % (tab, lib['description']))
            except KeyError:
                logger.warning('%s does not have a description.', lib['name'])

            print('%sScope:            %s' % (tab, lib['scope']))
            print('%sPath:             %s' % (tab, lib['path']))

            # Did the user request to see CAS ACLs?
            if listperms:

                # Build the CAM url for this library
                crnt_url = '%s/%s/caslibControls/%s' % (url.replace(
                           'casManagement', 'casAccessManagement'),
                           crnt['name'], lib['name'])
                logger.debug('CAS ACL url for this library is %s', crnt_url)

                # Try and obtain the ACLs for the current library
                aclrc, acls, num_acls = getCASACL(crnt_url, token)

                # Were the ACLs for this library obtainable?
                if ((aclrc != SUCCESS) or (acls is None)):
                    msg = ('Could not obtain list of access controls '
                           'for library')
                    logger.error('%s %s.', msg, lib['name'])

                else:

                    # They were so display them
                    if num_acls == 0:
                        print('%sAccess Controls: (None)' % tab),
                    else:
                        print('%sAccess Controls: ' % tab),

                    # Loop through the ACLs, displaying them
                    processed = 0
                    for acl in acls:

                        # If we're just starting, use the current format
                        if processed == 0:

                            # Tabstop not needed
                            ts = ''
                        else:

                            # Tabstop needed
                            ts = '%s                  ' % tab

                        # Print the ACLs
                        print('%sOrigin: %s, Type: %s, Permission: %s, '
                              'identityType: %s, identity: %s' %
                              (ts, acl['origin'],
                               acl['type'], acl['permission'],
                               acl['identityType'], acl['identity']))

                        # One down
                        processed += 1

            # Prepare a place for this next artifact
            print('\n')

    # All's well, so return success
    return SUCCESS


def getServerTables(library, url, token):
    """
    Obtains the list of a specific library's tables
    """

    # Initialization
    TABLES = 'tables'
    tables_url = '%s/%s/%s' % (url, library, TABLES)

    logger.debug('table url is %s', tables_url)

    try:

        # Open the connection to CAS Management and get the list of tables
        item_req = urllib2.Request(tables_url)
        item_req.add_header('Authorization', token)
        item_req.add_header('Response Content Type',
                            'application/vnd.sas.collection+json')
        item_response = urllib2.urlopen(item_req)
        item_read_code = item_response.getcode()
        read_item_response = item_response.read()
        dumped_response = json.loads(read_item_response)
        item_response.close()

    except urllib2.HTTPError, error:

        # Close the connection if it was opened
        if 'item_response' in locals():
            logger.debug('Closing the response handle %s', item_response)
            item_response.close()

        # Log what happened and inform the user
        contents = error.read()
        dumped_contents = json.loads(contents)
        logger.warning('HTTP Status Code: %s',
                       dumped_contents['httpStatusCode'])
        print('WARNING: %s\n' % dumped_contents['message'])
        return errno.ECONNREFUSED, None

    # Return success and the current colllection of tables
    return SUCCESS, dumped_response['items']


def listTables(url, token):
    """
    Lists all available CAS tables in a deployment
    """

    # Constants
    LIBRARIES = 'caslibs'

    # Obtain the list of servers first
    srvrc, servers = listServers(url, token)

    # Was the lists of servers obtainable?
    if ((srvrc != SUCCESS) or (servers is None)):
        logger.critical('Could not obtain list of servers.')
        print('Program aborting.')
        return rc, None

    # We have the servers, now get the caslibs
    for server in servers:

        # Build the url
        srv_url = '%s/%s/%s' % (url, server['name'], LIBRARIES)
        logger.debug('current server is %s', server['name'])
        logger.debug('server url is %s', srv_url)

        # Get the caslibs for the current server
        lrc, libraries = getServerLibraries(srv_url, token)

        # Was the list of caslibs obtainable?
        if ((lrc != SUCCESS) or (libraries is None)):

            # They weren't, so log this and return
            logger.critical('Could not obtain list of caslibs for server',
                            '%s.', crnt['name'])
            print('Program aborting.')
            return lrc

        # We have the caslibs so list the tables
        for library in libraries:

            # Obtain the list of tables for the current caslib
            trc, tables = getServerTables(library['name'], srv_url, token)

            # Was the lists of tables for this caslib obtainable?
            if ((trc != SUCCESS) or (tables is None)):

                # No, log this and effectively skip this caslib
                msg = 'Could not obtain list of tables for caslib'
                logger.error('%s %s.', msg, library['name'])

            else:

                # Let the user know how many tables were returned
                count = len(tables)
                print('caslib %s on server %s has %s tables.\n' % (
                      library['name'], server['name'], count))

                # Do we have the tables for the current library
                if count > 0:

                    # We do, so loop through them printng information for each
                    for table in tables:
                        print('%sName:                   %s' % (tab,
                              table['name']))

                        # Source tables may not exist for stream loaded tables
                        try:
                            print('%sSource Table Name:      %s' % (tab,
                                  table['tableReference']['sourceTableName']))
                        except KeyError:
                            logger.warning('%s does not have a source table',
                                           table['name'])

                        # Continue on with the display of information
                        print('%sTable URI:              %s' % (tab,
                              table['tableReference']['tableUri']))

                        # Scope may not always be defined
                        try:
                            print('%sScope:                  %s' % (tab,
                                  table['scope']))
                        except KeyError:
                            logger.warning('%s does not have a scope defined',
                                           table['name'])

                        # Continuing
                        print('%sState:                  %s' % (tab,
                              table['state']))

                        # Attributes may not always be defined
                        try:
                            print('%sOwner:                  %s' % (tab,
                                  table['attributes']['owner']))
                            print('%sGroup:                  %s' % (tab,
                                  table['attributes']['group']))
                            print('%sSize:                   %s' % (tab,
                                  table['attributes']['size']))
                        except KeyError:
                            logger.warning('%s has no attributes defined',
                                           table['name'])

                        # Did the user request to see CAS ACLs?
                        if listperms:

                            # Build the CAM url for this table
                            crnt_url = '%s/%s/caslibs/%s/tableControls/%s' % (
                                       url.replace('casManagement',
                                                   'casAccessManagement'),
                                       server['name'], library['name'],
                                       table['name'])
                            logger.debug('CAS ACL url for this library is %s',
                                         crnt_url)

                            # Try and obtain the ACLs for the current table
                            aclrc, acls, num_acls = getCASACL(crnt_url, token)

                            # Were the ACLs for this table obtainable?
                            if ((aclrc != SUCCESS) or (acls is None)):

                                # No, log this and effectively skip this
                                # table's permissions
                                msg = ('Could not obtain list of access '
                                       'controls for table')
                                logger.error('%s %s.', msg, table['name'])
                            else:

                                # They were so display them

                                # If no ACLs were returned, display that
                                if num_acls == 0:
                                    print('%sAccess Controls:        (None)' %
                                          tab),
                                else:
                                    print('%sAccess Controls:       ' % tab),

                                # Keep track of how many processed in order to
                                # format the output correctly
                                processed = 0

                                # Loop through the ACLs, displaying them
                                for acl in acls:

                                    # If we're just starting, use the current
                                    # format
                                    if processed == 0:

                                        # Tabstop not needed
                                        ts = ''
                                    else:

                                        # Tabstop needed
                                        ts = '%s                        ' % tab

                                    # Print the ACLs
                                    print('%sOrigin: %s, Type: %s, '
                                          ' Permission: %s, '
                                          'identityType: %s, identity: %s' %
                                          (ts, acl['origin'],
                                           acl['type'], acl['permission'],
                                           acl['identityType'],
                                           acl['identity']))

                                    # One down
                                    processed += 1

                        # Prepare a place for this next artifact
                        print('\n')

                print('')

    return SUCCESS


def displayTree(url, token):
    """
    Displays CAS Servers, caslibs, and tables in a given deployment in
    a tree view
    """

    # Constants
    LIBRARIES = 'caslibs'

    # Obtain the list of servers first
    srvrc, servers = listServers(url, token)

    # Was the lists of servers obtainable?
    if ((srvrc != SUCCESS) or (servers is None)):
        logger.critical('Could not obtain list of servers.')
        print('Program aborting.')
        return rc, None

    # We have the servers, now get the libraries
    for server in servers:

        # Build the url to use to get the list of libraries
        srv_url = '%s/%s/%s' % (url, server['name'], LIBRARIES)
        logger.info('server url is %s', srv_url)

        # Start the tree with the name of the current server
        print(server['name'])

        # Get the CAS libraries for the current server
        lrc, libraries = getServerLibraries(srv_url, token)

        # Was the lists of servers obtainable?
        if ((lrc != SUCCESS) or (libraries is None)):
            logger.critical('Could not obtain list of libraries for server',
                            '%s.', crnt['name'])
            print('Program aborting.')
            return lrc

        # We have the libraries so obtain the tables
        for library in libraries:

            # Continue the tree with the current library
            print('  +--%s' % library['name'])
            trc, tables = getServerTables(library['name'], srv_url, token)

            # Was the lists of tables for this library obtainable?
            if ((trc != SUCCESS) or (tables is None)):
                msg = 'Could not obtain list of tables for library'
                logger.error('%s %s.', msg, library['name'])

            else:

                # Do we have the tables for the current library
                if len(tables) > 0:

                    # Display them in the tree
                    for table in tables:
                        print('  |  +--%s' % table['name'])

        # Preapre for the next server
        print('')

    # All's good
    return SUCCESS


def refreshTable(table_url, table, caslib, token):
    """
    Makes sure the state of the specified table is loaded and that its scope is
    global.
    """

    # Build the URL to use
    table_url_state = '%s/state' % table_url
    logger.debug('table url to use is %s', table_url_state)

    try:

        # Prepare to to make sure the tables are loaded and global
        table_data = 'value=loaded&scope=global'

        # Setup to open the connection
        item_req = urllib2.Request(table_url_state, data=table_data)
        item_req.add_header('Authorization', token)
        item_req.add_header('Accept', 'application/json')
        item_req.add_header('Response Content Type',
                            'application/vnd.sas.collection+json')

        # Note this endpoint requires "PUT" as its verb which requires
        # overwriting urllib2.Request's get_method function
        item_req.get_method = lambda: 'PUT'

        # Open the connection, make the changes, and report back
        item_response = urllib2.urlopen(item_req)
        item_read_code = item_response.getcode()
        read_item_response = item_response.read()

        # Log what happened
        logger.debug('HTTP Status Code Returned: %s', item_read_code)
        logger.info('State for CAS Table %s in caslib %s is now %s', table,
                    caslib, read_item_response)

    # Any excaptions, if so log and return a failure
    except urllib2.HTTPError, tableE:

        # Close the connection if it was opened
        if 'item_response' in locals():
            logger.debug('Closing the response handle %s', item_response)
            item_response.close()

        error_response = json.loads(tableE.read())

        # Log what happened and inform the user
        logger.critical('%s', error_response['message'])
        logger.critical('HTTP Status Code %s: ',
                        error_response['httpStatusCode'])
        logger.critical('Details %s', json.dumps(error_response['details']))
        print('WARNING: %s' % error_response['message'])
        print('Unable to change the state of table %s to loaded.' % table)
        return errno.ECONNREFUSED

    # All good
    return SUCCESS


def isValidService(service):
    """
    Returns True if the service passed in as a valid microservice
    """

    if ('proxy' in service['ServiceTags']):
        if (service['ServiceName'] == 'SASStudio'):
            return False
        if '-http' in service['ServiceName']:
            return False
        return True


def getApiMetaInfo(url, token, service):
    """
    Obtains the api Meta information for a given servive
    """

    try:

        # Open the connection to the apiMeta endpoint
        item_req = urllib2.Request(url)
        item_req.add_header('Authorization', token)
        item_req.add_header('Response Content Type',
                            'application/vnd.sas.collection+json')
        item_response = urllib2.urlopen(item_req)
        item_read_code = item_response.getcode()
        read_item_response = item_response.read()
        dumped_response = json.loads(read_item_response)
        item_response.close()

    # Any errors?
    except urllib2.HTTPError, apiE:

        # Close the connection if it was opened
        if 'item_response' in locals():
            logger.debug('Closing the response handle %s', item_response)
            item_response.close()

        # Log what happened and inform the user
        print('%s - %s' % (service, apiE))
        return errno.ECONNREFUSED, None

    # All good, so return the information
    return SUCCESS, dumped_response


def getReports(url, token, number):
    """
    Obtains and returns a collection of reports
    """

    try:

        # Query data
        query_data = {'limit': number}
        encoded_query = urllib.urlencode(query_data)

        # Open the connection to the reports endpoint
        full_url = '%s/?%s' % (url, encoded_query)
        item_req = urllib2.Request(full_url)
        item_req.add_header('Authorization', token)
        item_req.add_header('Response Content Type',
                            'application/vnd.sas.collection+json')
        item_response = urllib2.urlopen(item_req)
        item_read_code = item_response.getcode()
        read_item_response = item_response.read()
        dumped_response = json.loads(read_item_response)
        item_response.close()

    # Any errors?
    except urllib2.HTTPError, repE:

        # Close the connection if it was opened
        if 'item_response' in locals():
            logger.debug('Closing the response handle %s', item_response)
            item_response.close()

        error_response = json.loads(repE.read())

        # Log what happened and inform the user
        logger.critical('%s', error_response['message'])
        logger.critical('HTTP Status Code %s: ',
                        error_response['httpStatusCode'])
        logger.critical('Details %s', json.dumps(error_response['details']))
        print('WARNING: %s' % error_response['message'])
        print('Unable to obtain a list of reports.')
        return errno.ECONNREFUSED, None

    # All good, so return the collection of reports
    return SUCCESS, dumped_response


def getFolders(url, token):
    """
    Obtains and returns a collection of folders
    """

    try:

        # Open the connection to the folders endpoint
        item_req = urllib2.Request(url)
        item_req.add_header('Authorization', token)
        item_req.add_header('Response Content Type',
                            'application/vnd.sas.collection+json')
        item_response = urllib2.urlopen(item_req)
        item_read_code = item_response.getcode()
        read_item_response = item_response.read()
        dumped_response = json.loads(read_item_response)
        item_response.close()

    # Any errors?
    except urllib2.HTTPError, folE:

        # Close the connection if it was opened
        if 'item_response' in locals():
            logger.debug('Closing the response handle %s', item_response)
            item_response.close()

        error_response = json.loads(folE.read())

        # Log what happened and inform the user
        logger.critical('%s', error_response['message'])
        logger.critical('HTTP Status Code %s: ',
                        error_response['httpStatusCode'])
        logger.critical('Details %s', json.dumps(error_response['details']))
        print('WARNING: %s' % error_response['message'])
        print('Unable to obtain a list of folders.')
        return errno.ECONNREFUSED, None

    # All good so return the collection of folders
    return SUCCESS, dumped_response

# Create Logger
logger = logging.getLogger(__name__)
