/*-------------------------------------------------------------------+
|                                                                    |
| Program: filelock.c                                                |
| Prototype Created: March 4, 2013                                   |
| Version: 1.00                                                      |
| Language: C                                                        |
| Tested Systems: C                                                  |
|                                                                    |
| Program Description:                                               |
|                                                                    |
| This menu-driven program can be used to request a Read or Write    |
| lock on a file and check the lock status of a file.                |
|                                                                    |
| Notes on limitations:                                              |
|                                                                    |
|    1. The same process that creates a lock on a file cannot        |
|       properly check the lock status of that file using fcntl(),   |
|       which is the only tool available to do such checking.        |
|       fcntl() issued from the same process that created the lock   |
|       reports that there are no locks on the file.                 |
|                                                                    |
|    2. If there are two instances of fopen() on a file (that is, 2  |
|       file descriptors for the same file), fclose() on one of those|
|       instances removes ALL locks on the file, whether created via |
|       fcntl() using the first file descriptor or the second file   |
|       descriptor.                                                  |
|                                                                    |
|    3. Because of (1) and (2), this program only allows the user to |
|       operate on one file at a time, and once a lock is placed,    |
|       the status of that lock can only be checked by a second      |
|       process.                                                     |
|                                                                    |
| File Locking Rules:                                                |
|                                                                    |
|    1. A file CAN have concurrent shared Read locks.                |
|                                                                    |
|    2. When one or more process has placed a Read lock on a file,   |
|       NO processes can have an exclusive Write lock on the file    |
|       and/or region of the file.                                   |
|                                                                    |
|    3. If one process has a Write lock established on a file, a     |
|       Read lock or another Write lock CANNOT be established on the |
|       same file.                                                   |
|                                                                    |
|    4. Only "regular" file types can have a file lock established.  |
|       File types of "directory", "block special", "fifo",          |
|       "symbolic links", "character special", and "socket" cannot   |
|       have file locks established on them.                         |
|                                                                    |
| Noted Operating System Functions:                                  |
|                                                                    |
|    The function from the UNIX API that establishes the file        |
|    locking requests or checks for existing file locks is fcntl(2). |
|    fcntl(2) is termed "file control". To perform file/record       |
|    locking on an existing file, the file type MUST be a regular    |
|    file.  The following is a list and the descriptions of the      |
|    possible file locking parameters for fcntl(2):                  |
|                                                                    |
|    F_GETLK:   Get the first lock which has a file locked. This     |
|               This parameter command returns the process id of the |
|               process that currently has the file locked. If there |
|               is no lock that would prevent a file lock to be      |
|               established, the value of F_UNLCK is passed back to  |
|               the flock.l_type structure entry.                    |
|                                                                    |
|    F_SETLK:   This value is used to set a Read lock ( F_RDLCK ),   |
|               Write lock ( F_WRLCK ), or clear ( F_UNLCK ) an      |
|               existing file lock.                                  |
|                                                                    |
|    flock()ata structure members:                                   |
|    =============================                                   |
|                                                                    |
|    short l_type   F_RDLCK, F_WRLCK, F_UNLCK                        |
|                   file locking types                               |
|    short l_start  starting byte offset in file                     |
|    off_t l_whence see lseek(2)                                     |
|    off_t l_len    number of bytes to lock.                         |
|                   if 0, then locks entire file.                    |
|    pid_t l_pid    process holding lock                             |
|                                                                    |
| Notes on file locking across NFS:                                  |
|                                                                    |
|    The network daemons "rpc.statd" and "rpc.lockd" perform NFS     |
|    file locking requests. If there are problems establishing file  |
|    locks on files across NFS, these network daemons may need to be |
|    restarted on both the server and the client NFS machine.        |
|    Please refer this task to your UNIX system administrator.       |
|    Reference your Operating System documentation for more          |
|    information.                                                    |
|                                                                    |
+-------------------------------------------------------------------*/
#include <stdio.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>
#include <stdlib.h>
#include <unistd.h>


int rc;                   /* Return code */
int fd = 0;               /* File descriptor from open(2) */  
char filename[1024];      /* Space to hold filename */
char *file = filename;    /* Ptr to filename */
char c[1024];             /* Space to hold user input */
char *choice = c;         /* Ptr to user input */
int menuchoice;           /* User's choice from menu */
struct flock lock;        /* For fcntl() */
int locked = 0;           /* Boolean if a read or write lock has been est. by the process */
char command[60];  
struct stat sb;

/*******************************************************************************************************************************/
/* create a file                                                                                                               */
/*******************************************************************************************************************************/
createfile()
{
	FILE *fp;
	if (NULL == (fp = fopen(file , "w+"))) 
  	  {
		fprintf(stderr, "<<ERROR>>    Error creating file: %s\n", strerror(errno));
  	  }
	else  
	  {
		fprintf(stdout, "<<STATUS>>   File opened for write successfully\n");
	  }
}

/*******************************************************************************************************************************/
/* remove a file                                                                                                               */
/*******************************************************************************************************************************/
deletefile()
{
	if (rc = remove(file) != 0)
	  {
		fprintf(stderr, "<<ERROR>>    Error deleting file: %s\n", strerror(errno));
	  }
	else  
	  {
		fprintf(stdout, "<<STATUS>>   File deleted successfully\n");
	  }
}

/*******************************************************************************************************************************/
/* remove lock created by this application                                                                                     */
/*******************************************************************************************************************************/
removelock()
{
	if (locked == 1)
	  {
		if (rc = close(fd) == -1) 
		  {
			fprintf(stderr, "<<WARNING>>  Error closing file: %s\n", strerror(errno));
		  }
		else  
	  	  {
			fprintf(stdout, "<<STATUS>>   File lock removed successfully\n");
			fd = 0;
			locked = 0;
		  }
	  }
	else  
	  {
		fprintf(stdout, "<<STATUS>>   File was not locked by this application\n");
	  }
}

/*******************************************************************************************************************************/
/* create read lock                                                                                                            */
/*******************************************************************************************************************************/
readlock()
{
	if ((fd = open(file, O_RDONLY)) < 0) 
	  {
		fprintf(stderr, "<<ERROR>>    Unable to open file for READ: %s\n", strerror(errno));
	  }
	else	/* attempt a read lock */
	  {
		lock.l_type = F_RDLCK;    /* F_RDLCK, F_WRLCK, F_UNLCK */
		lock.l_start = 0;         /* byte offset, relative to l_whence */
		lock.l_whence = SEEK_SET; /* SEEK_SET, SEEK_CUR, SEEK_END */
		if ((rc = fcntl(fd, F_SETLK, &lock)) == -1) 
		  {
			fprintf(stderr, "<<ERROR>>    Unable to establish a READ lock on file: %s\n", strerror(errno));
		  }
		else 
		  {
			fprintf(stdout, "<<STATUS>>   A READ lock has been established for file\n"); 
			locked = 1;
		  }
	  }
}

/*******************************************************************************************************************************/
/* create write lock                                                                                                           */
/*******************************************************************************************************************************/
writelock()
{
	if ((fd = open(file, O_RDWR)) < 0) 
	  {
		fprintf(stderr, "\n<<ERROR>>    Unable to open file for WRITE: %s\n", strerror(errno));
	  }
	else /* attempt a write lock */
	  {
		lock.l_type = F_WRLCK;    /* F_RDLCK, F_WRLCK, F_UNLCK */
		lock.l_start = 0;         /* byte offset, relative to l_whence */
		lock.l_whence = SEEK_SET; /* SEEK_SET, SEEK_CUR, SEEK_END */
		if ((rc = fcntl(fd, F_SETLK, &lock)) == -1) 
		  {
			fprintf(stderr, "<<ERROR>>    Unable to establish a WRITE lock on file: %s\n", strerror(errno));
		  }
		else 
		  {
			fprintf(stdout, "<<STATUS>>   A WRITE lock has been established for file\n"); 
			locked = 1;
		  }
	  }
}

/*******************************************************************************************************************************/
/* describe file                                                                                                               */
/*******************************************************************************************************************************/
describefile()
{
/*	lock.l_type = F_WRLCK; */
	if (stat(file, &sb) == -1) 
	  {
		exit(EXIT_FAILURE);
	  }
	else
	  {
		printf("\nFile type               : ");
		switch (sb.st_mode & S_IFMT) 
		  {
			case S_IFBLK:  printf("block device\n");            break;
			case S_IFCHR:  printf("character device\n");        break;
			case S_IFDIR:  printf("directory\n");               break;
			case S_IFIFO:  printf("FIFO/pipe\n");               break;
			case S_IFLNK:  printf("symlink\n");                 break;
			case S_IFREG:  printf("regular file\n");            break;
			case S_IFSOCK: printf("socket\n");                  break;
			default:       printf("unknown?\n");                break;
		  }
		printf("I-node number           : %ld\n", (long) sb.st_ino);
		printf("Mode                    : %lo (octal)\n", (unsigned long) sb.st_mode);
		printf("Link count              : %ld\n", (long) sb.st_nlink);
		printf("Ownership               : UID=%ld   GID=%ld\n", (long) sb.st_uid, (long) sb.st_gid);
		printf("Preferred I/O block size: %ld bytes\n", (long) sb.st_blksize);
		printf("File size               : %lld bytes\n", (long long) sb.st_size);
		printf("Blocks allocated        : %lld\n", (long long) sb.st_blocks);
		printf("Last status change      : %s", ctime(&sb.st_ctime));
		printf("Last file access        : %s", ctime(&sb.st_atime));
		printf("Last file modification  : %s\n", ctime(&sb.st_mtime));
	  }
}

/*******************************************************************************************************************************/
/* file status                                                                                                                 */
/*******************************************************************************************************************************/
filestatus()
{
	char* dir; 
	if ((fd = open(file, O_RDONLY)) < 0) 
	  {
		fprintf(stderr, "<<ERROR>>    Unable to open file for READ: %s\n", strerror(errno));
	  }
	else
	  {
		describefile();
		lock.l_type = F_WRLCK;
		lock.l_start = 0;
		lock.l_whence = SEEK_SET;
		lock.l_len = 0;
		lock.l_pid    = getpid();
		fprintf(stdout, "Details:\n\n");
		if ((rc = fcntl(fd, F_GETLK, &lock)) == -1) 
		  {
			fprintf(stderr, "<<ERROR>>    Unable to get status on file %s\n", strerror(errno));
		  }
		else 	if ( lock.l_type == F_RDLCK ) 
			  {
				fprintf(stdout, "\nlock results:\n\n");
				fprintf(stdout, "There is an existing READ lock on file\n");
				fprintf(stdout, "The process id that holds this READ lock is %d.\n", lock.l_pid);
				fprintf(stdout, "\nps results:\n\n");
				sprintf(command,"ps -aef | grep %d | egrep -v grep", lock.l_pid);
				rc = system(command);
			  }
			else 	if ( lock.l_type == F_WRLCK ) 
				  {
					fprintf(stdout, "\nlock results:\n\n");
					fprintf(stdout, "There is an existing WRITE lock on file\n");
					fprintf(stdout, "The process id that holds this WRITE lock is %d.\n", lock.l_pid);
					fprintf(stdout, "\nps results:\n\n");
					sprintf(command,"ps -aef | grep %d | egrep -v grep", lock.l_pid);
					rc = system(command);
				  }
			fprintf(stdout, "\ndf results:\n\n");
			sprintf(command,"df -P %s", file);
			rc = system(command);
  			FILE *fp;
  			char path[1035]="";
			sprintf(command,"df -P %s | awk \'{ print $6 }\' | tail -1", file);
  			fp = popen(command, "r");
  			if (fp != NULL) 
		  	  {
  				if (fgets(path, sizeof(path)-1, fp) != NULL) 
				  {
					fprintf(stdout, "\nmount results:\n\n");
    					sprintf (command,"mount | grep %s", path);
    					rc=system(command);
					fprintf(stdout, "\n");
  					pclose(fp);
  				  }
		  	}
	  }
}

/*******************************************************************************************************************************/
/* get a file name                                                                                                             */
/*******************************************************************************************************************************/
getfilename()
{
	if (menuchoice != 6 && menuchoice != 0) 
	  {
		if (locked != 1) 
		  {
			fprintf(stdout,"<<REQUEST>>  Enter filename: ");
			scanf("%s", file);
		  }
		else
		  {
			fprintf(stdout,"<<STATUS>>   Processing filename: %s\n", file);
		  }
	  }
}

/*******************************************************************************************************************************/
/* main                                                                                                                        */
/*******************************************************************************************************************************/
main(int argc, char *argv[])
  {
	if (argc != 1) 
	  {
      		fprintf(stderr, "\n\"%s\" is a menu-driven program that\n", argv[0]);
      		fprintf(stderr, "does not require command line arguments.\n");
      		fprintf(stderr, "\"%s\" and any subsequent arguments ignored.\n\n", argv[1]);
	  }
	while (1) 
	  {
         	fprintf(stdout,"\n\n***********************************\n");
         	fprintf(stdout,"\nMenu:\n");
		if (locked == 1)
		  {
         		fprintf(stdout,"   0. Request file lock removal\n");
         		fprintf(stdout,"   5. Request file STATUS\n");
      			fprintf(stdout,"   6. Exit\n");
		  }
		else
		  {
         		fprintf(stdout,"   1. Create a writeable file\n");
         		fprintf(stdout,"   2. Remove a writable file\n");
         		fprintf(stdout,"   3. Create file read lock\n");
         		fprintf(stdout,"   4. Create file write lock\n");
         		fprintf(stdout,"   5. Request file status\n");
      			fprintf(stdout,"   6. Exit\n");
		  }
      		fprintf(stdout,"Select option: ");
      		scanf("%s", c);
      		fprintf(stdout,"\n");
		menuchoice = atoi(c);
      		if  (( strlen(c) != 1 ) || ( isdigit(*c) == 0 ))
		  {
          		fprintf(stderr, "<<ERROR>>    Invalid option.  Enter 6 to exit.\n");
         		menuchoice = -1;
         	  }
      		else
		  {
			if (((locked == 1) && (menuchoice == 0 || menuchoice == 5 || menuchoice == 6)) ||
			    ((locked == 0) && (menuchoice != 0 )) && (menuchoice <= 6))
			  {
				getfilename();
      				switch (menuchoice)
         	  		  {
         				case -1:
            					break;
         				case 0: 
						removelock();
            					break;
         				case 1: /* create file */
						createfile();
            					break;
         				case 2: /* delete file */
						deletefile();
            					break;
         				case 3: /* read lock */
						readlock();
            					break;
         				case 4: /* write lock */
						writelock();
            					break;
         				case 5: /* status of a file */
						filestatus();
            					break;
         				case 6: /* exit */
            					fprintf(stdout, "<<STATUS>>   Exit, stage left!\n");
            					exit(0);
		  		  } /* switch */
			  }
			else
			  {
			 	fprintf(stderr, "<<ERROR>>    Invalid option.\n");
		  	  }
		  }
	  } /* while */
   } /* main */
