#!/usr/bin/env python
#
# getVAReports.py
#
# Usage
#
#    getVAReports.py       [-h] [-user USER] [-password PASSWORD]
#                          [-limit LIMIT] [-d] [-v] [-nologging]
#
#        optional arguments:
#            -h, --help          show this help message and exit
#            -user USER          user id to connect with
#            -password PASSWORD  password used to connect with
#            -limit LIMIT        limit of reports to return (defaults to 20)
#            -d, --debug         prints useful debug information
#            -v, --verbose       prints verbose information
#            -nologging          prevents any log messages from being displayed
#
# Return Codes
#
# 0            - Success
# ENOENT       - No such file or directory
# ESRCH        - No such process
# EPERM        - Operation not permitted
# ENXIO        - No such device or address
# ECONNREFUSED - Connection refused
# ?            - Any return from subprocess.Popen()

import argparse
import errno
import getpass
import json
import logging
import support_utilities as s_u
import sys


# Create Logger
logger = logging.getLogger(__name__)

# Make sure Pyton 2 is being used
if sys.version_info[0] >= 3:
    raise AssertionError('This program runs under Python 2')


def main():

    # Parse the command line
    parser = argparse.ArgumentParser(description='Lists all SAS VA on Viya \
                                     reports in the current deployment.')
    parser.add_argument('-user', help='user id to connect with')
    parser.add_argument('-password', help='password used to connect with')
    parser.add_argument('-limit', help='number of reports to return \
                        (defaults to 20)', type=int, default=20)
    parser.add_argument('-d', '--debug', action='store_const',
                        dest='loglevel', const=logging.DEBUG,
                        default=logging.WARNING,
                        help='prints useful debug information')
    parser.add_argument('-v', '--verbose', action='store_const',
                        dest='loglevel', const=logging.INFO,
                        help='prints verbose information')
    parser.add_argument('-nologging', action='store_true',
                        help='prevents any log messages from being displayed')
    args = parser.parse_args()

    # Set the logging configuration
    format = '%(levelname)s: %(asctime)-15s %(message)s'
    logging.basicConfig(level=args.loglevel, format=format)

    # Turn off all logging if the user desires
    if args.nologging:
        logger.disabled = True

    # DEBUG
    logger.debug('Command line arguments - %s', str(args))

    # Assorted constants
    SASLOGON = 'SASLogon/oauth/token'
    REPORTS = 'reports/reports'

    # Let the user know things are progressing
    print('Starting analysis of this deployment.\n')

    # Verify CSQ exists on the system
    if not s_u.isSystemValid():
        return errno.ENOENT

    # Verify Consul is active
    consul_status = s_u.validateConsul()
    if not consul_status:
        return consul_status

    # Determine a valid HTTP system to talk to
    httpd_host, httpd_port = s_u.getHTTPDHostAndPort()

    # If no system is found, abort the application
    if (str(httpd_host) is None) or (str(httpd_port) is None):
        return errno.ENXIO

    logger.debug('httpd host is %s', httpd_host)
    logger.debug('httpd port is %s', httpd_port)

    # Deterime the username
    if not args.user:
        logger.debug('Requesting username')
        print('Please enter the credentials you wish to connect with.\n')
        user = raw_input('Username: ')
    else:
        logger.debug('username passed via command line')
        user = args.user

    # Determine the password for the given user
    if not args.password:
        logger.debug('Requesting password')
        passwd = getpass.getpass('Password for %s:' % user)
    else:
        logger.debug('password passed via command line')
        passwd = args.password

    logger.info('Credentials obtained.')

    # Obtain the auth token
    sl_url = 'http://%s:%s/%s' % (httpd_host, httpd_port, SASLOGON)
    rc, auth_header = s_u.getAuthToken(sl_url, user, passwd)

    # Was the auth token obtained? If not, exit
    if ((rc != s_u.SUCCESS) or (auth_header is None)):
        return rc

    # Build the url to use to fetch a list of reports
    rep_url = 'http://%s:%s/%s' % (httpd_host, httpd_port, REPORTS)

    # Now obtain the list of reports for this deployment based on the
    # limit specified
    reprc, reports = s_u.getReports(rep_url, auth_header, args.limit)

    # Keep track of failures
    issues_found = False

    # Were the reports for this deployment obtainable?
    if ((reprc != s_u.SUCCESS) or (reports is None)):
        msg = 'Could not obtain list of reports for this deployment.'
        logger.error('%s', msg)
        print('\nApplication completed with errors. Exiting...')

    else:

        # There may not be a count so compute what we got back
        try:
            count = reports['count']
        except KeyError:
            count = len(reports['items'])

        # Do we have reports
        if count > 0:

            # We do, so display some information
            print('Displaying %s SAS VA on Viya reports.\n' % count)

            # Iterate through the reports, displaying pertinent information
            for report in reports['items']:
                print('Name:        %s' % report['name'])
                print('Created By:  %s' % report['createdBy'])
                print('Created On:  %s' % report['creationTimeStamp'])
                print('Modified By: %s' % report['modifiedBy'])
                print('Modified On: %s\n' % report['modifiedTimeStamp'])

        else:

            # There are no reports on this system
            print('WARNING: There are no reports in this system.')
            issues_found = True

        # Any issues?
        if issues_found:
            print('\nApplication completed with issues. Exiting...')
        else:
            print('\nApplication completed successfully. Exiting...')

# Begin program
if __name__ == '__main__':
    sys.exit(main())
