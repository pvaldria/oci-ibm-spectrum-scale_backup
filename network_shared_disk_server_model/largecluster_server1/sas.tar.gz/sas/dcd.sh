usage ()
{
	echo ""
	echo ""
 	echo "INVOCATION: ${PROG} -v <SAS version> -t <SAS track number> -l <log type> -d <number>"
 	echo ""
 	echo "FUNCTION  : collect SAS logs for track debugging"
 	echo ""
 	echo "REQUIRED  : -v <SAS version> identifies the SAS version with this issue.  Valid values:"
 	echo "               -- 9.3"
 	echo "               -- 9.4"
 	echo ""
 	echo "            -t <SAS track number> identifies the 10 digit SAS track number to be associated with this issue."
 	echo "            -l <log type> identifies the SAS logs to collect.  Valid values:"
 	echo "               -- deployment"
 	echo "               -- running"
 	echo ""
	echo "OPTIONAL  : -d <days> number of log days to collect relative to today (default is 3)"
	echo "            -e collect environment information only"
 	exit 1
}

initialize ()
{
	export SASHOME=NA
	export SASCONFIG=NA
	export SASLEVEL=NA
	export OS=`uname | tr '[a-z]' '[A-Z]'`
	case "${OS}" in
	  AIX)		MOUNTCMD=mount
			SWAPCMD="lsps -a"
			TAROPTIONS="cZf"
			;;
	  HP-UX)	MOUNTCMD=/sbin/mount
			SWAPCMD="vmstat"
			TAROPTIONS="cf"
			;;
	  SUNOS)	MOUNTCMD=/sbin/mount
			SWAPCMD="kstat -c pages"
			TAROPTIONS="czf"
			;;
	  *)		MOUNT=mount
			SWAPCMD=free
			TAROPTIONS="czf"
			;;
	esac
	export TARDIR=/tmp/tardir.${RANDOM}
	mkdir ${TARDIR}
	HOSTNAME=`hostname | awk -F\. '{ print $1 }'`
	TARFILENAME=T${TRACK}_dcdTool_Date`date +%Y-%m-%d_Time%H%M%S`.tar
	export STATUSFILE=${TARDIR}/${SAS_VERSION}-${TRACK}.status
	export TMPFILE=/tmp/tmpfile.${RANDOM}
	export LIST=/tmp/list.${RANDOM}
	RMLIST="${STATUSFILE} ${TMPFILE} ${LIST} extendables deployment.manifest "
}
 
validate_arguments ()
{
	TNMAX=10
	STARTVAL=7612
	case "${SAS_VERSION}" in
	  9.3)	SAS_PREFERENCES=${HOME}/.SASAppData/SASDeploymentWizard/sdwprefs.txt
		;;
	  9.4)	SAS_PREFERENCES=${HOME}/.SASAppData/SASDeploymentWizard/sdwpreferences.txt
		;;
	  *)	echo "<<ERROR>>  invalid SAS version value: [${SAS_VERSION}]"
		RC=1
		;;
	esac
	case "${TRACK}" in
	  ${STARTVAL}[0-9][0-9][0-9][0-9][0-9][0-9])	;;
	  *)		echo  "<<ERROR>>  track must contain [${TNMAX}] digits and start with value [${STARTVAL}]"
			RC=1
			;;
	esac 
	case "${LOGTYPE}" in
          deployment)	;;
          running)	;;
	  *)		echo  "<<ERROR>>  invalid logtype [${LOGTYPE}] entered"
			RC=1
			;;
	esac
	DAYS=${DAYS:-3}
        expr ${DAYS} + 0 >/dev/null 2>&1
	if [ $? -ne 0 ]
          then  echo "<<ERROR>>  days duration [${DAYS}] is not numeric"
          	RC=1
	fi
	if [ ${RC} -eq 1 ]
	  then	usage
	  else	if [ ! -f "${SAS_PREFERENCES}" ]
  	  	  then	echo "<<ERROR>>  SAS [${SAS_VERSION}] preferences file [${SAS_PREFERENCES}] does not exist" 
			RC=1
	  	  else	initialize
			select_SASHOME
		fi
	fi
}

select_VALUE ()
{
	SC=${1}
	TYPE=${2}
	if [ ${SC} = 1 ] 
	  then	ITEM=${ARRAY[1]}
	  else 	FOUND=false
		SM=${SC}
	  	while [ "${FOUND}" = "false" ]
		  do
			echo ""
			echo "Multiple values for ${TYPE} detected ..."
			echo ""
			SC=0
			while [ ${SC} -lt ${SM} ]
		  	  do
				((SC=SC+1))
				echo "  ${SC}    ${ARRAY[$SC]}"
		  	  done
			echo ""
			if [ `uname` = "AIX" -o `uname` = "HP-UX" ]
		  	  then	echo "<<ACTION>> Please select ${TYPE} value [1-${SM}]: \c"
		  	  else	echo -n "<<ACTION>> Please select ${TYPE} value [1-${SM}]: "
			fi
			read VALUE
			if [ ${VALUE} -le ${SM} ]
		  	  then	ITEM=${ARRAY[$VALUE]}
				FOUND=true
			fi
	  	  done
	fi
}

select_SASLEVEL()
{
	SLC=0
	ls -1d ${SASCONFIG}/Lev[0-9] >${TMPFILE} 2>/dev/null
	while read RECORD
	  do
		((SLC=SLC+1))
		ARRAY[$SLC]="${RECORD}"
	  done < ${TMPFILE}
       	if [ "${SLC}" -eq 0 ]
	  then	if [ "${LOGTYPE}" != "deployment" ]
          	  then	echo "<<ERROR>>  No valid level configuration attempts for SAS [${SAS_VERSION}] detected"
			RC=1
		fi
	  else	select_VALUE ${SLC} SASLEVEL
		export SASLEVEL=${ITEM}
	fi
}

select_SASCONFIG ()
{
	SCC=0
	while read RECORD 
	  do
		case "${RECORD}" in
		  '<Key name="Configuration'*)	read R2
						CONFIG=`echo ${R2} | awk -F\= '{ print $2 }' | sed "s;\";;g" | awk '{ print $1 }' | sed "s;/../..;;"`
						if [ -d "${CONFIG}" ]
						  then	((SCC=SCC+1))
							ARRAY[$SCC]="${CONFIG}"
						fi
						;;
					   *)	;;
		esac
	  done <${SASDEPLOYMENTREG}
       	if [ "${SCC}" -eq 0 ]
	  then	if [ "${LOGTYPE}" != "deployment" ]
        	  then	echo "<<ERROR>>  No valid configuration attempts for SAS [${SAS_VERSION}] detected"
        		RC=1
		fi
	  else	select_VALUE ${SCC} SASCONFIG
		export SASCONFIG=${ITEM}
		select_SASLEVEL
	fi
}
 
select_SASHOME ()
{
	SHC=0
	grep "SASHome" ${SAS_PREFERENCES} | awk -F\= '{ print $2 }' | sort -u  >${TMPFILE}
	while read RECORD
	  do
		if [ -d "${RECORD}" ]
		  then	((SHC=SHC+1))
			ARRAY[$SHC]="${RECORD}"
		fi
	  done <${TMPFILE}
	if [ "${SHC}" -eq 0 ]
	  then	echo "<<ERROR>>  No valid installation attempts for SAS [${SAS_VERSION}] detected" 
		RC=1
	  else	select_VALUE ${SHC} SASHOME
		export SASHOME=${ITEM}
		SASDEPLOYMENTREG=${SASHOME}/deploymntreg/registry.xml
		if [ ! -f "${SASDEPLOYMENTREG}" ]
          	  then	echo "<<ERROR>>  No valid configuration attempts for SAS [${SAS_VERSION}] detected"
	  		RC=1
		  else	echo "${SASDEPLOYMENTREG}" >${LIST}
			select_SASCONFIG
		fi
	fi
}
 
get_sdw_log ()
{
        echo "SYSTEM PROPERTIES" >>${STATUSFILE}
        echo "-----------------" >>${STATUSFILE}
	SDW_LOG=`egrep "sas.home.dir = ${SASHOME}\$" ${HOME}/.SASAppData/SASDeploymentWizard/SDW_2*.log | sort -r | head -1 | awk -F\: '{ print $1 }'`
	if [ -f "${SDW_LOG}" ]
          then 	echo "      SDW LOG:          ${SDW_LOG}" >>${STATUSFILE}
        	PLAN_FILE=`grep "Plan File:" ${SDW_LOG} | awk -F\: '{ print $2 }' | sed "s; ;;g"`
        	echo "      Plan File:        ${PLAN_FILE:-does not exist}" >>${STATUSFILE}
        	grep "User ID:" ${SDW_LOG} >>${STATUSFILE}
        	grep "User Home:" ${SDW_LOG} >>${STATUSFILE}
        	grep "Temp Directory:" ${SDW_LOG} >>${STATUSFILE}
        	grep "Java Version:" ${SDW_LOG} >>${STATUSFILE}
        	grep "Java Home:" ${SDW_LOG} >>${STATUSFILE}
        	grep "OS Name:" ${SDW_LOG} >>${STATUSFILE}
        	grep "OS Architecture:" ${SDW_LOG} >>${STATUSFILE}
        	grep "OS Version:" ${SDW_LOG} >>${STATUSFILE}
        	grep "Software Version:" ${SDW_LOG} >>${STATUSFILE}
        	grep "Platform Code:" ${SDW_LOG} >>${STATUSFILE}
        	grep "Host Name:" ${SDW_LOG} >>${STATUSFILE}
		SITENUM=`grep "sid.site.num = " ${SDW_LOG} | awk -F = '{ print $2 }'`
		echo "      Site Number:     ${SITENUM}" >>${STATUSFILE}
        	grep "Order Number:" ${SDW_LOG}  >>${STATUSFILE}
        	grep "Image Directory:" ${SDW_LOG} >>${STATUSFILE}
		DEPOT=`grep "Image Directory:" ${SDW_LOG} | awk -F\: '{ print $2 }' | sed "s; ;;g"`
		DEPOT=${DEPOT:-NA}
          else	echo "      SDW LOG:          not found" >>${STATUSFILE}
		DEPOT=NA
	fi
}

create_details_file ()
{
	get_sdw_log
        echo "" >>${STATUSFILE}
        echo "ULIMITS (ulimit -a)" >>${STATUSFILE}
	echo "-------------------" >>${STATUSFILE}
	ulimit -a >>${STATUSFILE}
        echo "" >>${STATUSFILE}
        echo "DISK SPACE (df -k)" >>${STATUSFILE}
	echo "------------------" >>${STATUSFILE}
	df -k 2>/dev/null >>${STATUSFILE}
        echo "" >>${STATUSFILE}
        echo "MOUNT [mount]" >>${STATUSFILE}
	echo "-------------" >>${STATUSFILE}
	${MOUNTCMD} >>${STATUSFILE}
        echo "" >>${STATUSFILE}
	echo "SWAP SIZE [${SWAPCMD}]" >>${STATUSFILE}
	echo "------------------------------" >>${STATUSFILE}
	${SWAPCMD} >> ${STATUSFILE}
	echo "" | tee -a ${STATUSFILE}
	echo "BEGIN COLLECTION" | tee -a ${STATUSFILE}
	echo "----------------" | tee -a ${STATUSFILE}
	echo "" | tee -a ${STATUSFILE}
	echo "<<CMD>>    ${PROG} ${ARGS}" | tee -a ${STATUSFILE}
	echo "" | tee -a ${STATUSFILE}
	echo "<<SASENV>> SAS HOME:         ${SASHOME}" | tee -a ${STATUSFILE}
        echo "           SAS CONFIG:       ${SASCONFIG}" | tee -a ${STATUSFILE}
        echo "           SAS LEVEL:        ${SASLEVEL}" | tee -a ${STATUSFILE}
	echo "" | tee -a ${STATUSFILE}
}

mask_cleartext_passwords ()
{
	cd ${TARDIR}
	find . -type f |
	while read FILE
  	  do
        	COUNT=`grep -c "{sas002}" ${FILE}`
        	if [ ${COUNT} -gt 0 ]
          	  then  cp ${FILE} ${FILE}.tmp1
        		grep "{sas002}" ${FILE} | awk -F\} '{ print $2 }' | awk '{ print $1 }' | sed "s;\";;g" | sed "s;\';;g" | sort -u |
        		while read TOKEN
          	  	  do
                		NEWTOKEN=`echo ${TOKEN} | sed "s;[A-Z,a-z,0-9];X;g"`
                		cat ${FILE}.tmp1 | sed "s;${TOKEN};${NEWTOKEN};g" >${FILE}.tmp2
                		mv ${FILE}.tmp2 ${FILE}.tmp1
          	  	  done
        		mv ${FILE}.tmp1 ${FILE}
		fi
  done
}

create_tarfile ()
{
        echo "           creating collection [${TARFILENAME}]" | tee -a ${STATUSFILE}
	cd ${TARDIR}
	tar ${TAROPTIONS} ${TARFILENAME} *
	if [ $? -eq 0 ]
	  then	echo "           collection ready for delivery"  
		ftp_tarfile
	  else	echo "<<ERROR>> collection creation failed"  
		RC=1
	fi
}

get_extendables ()
{
	mkdir ${TARDIR}/extendables
	echo "           executing extendables" | tee -a ${STATUSFILE}
	cd  ${TARDIR}/extendables
	ls -1 ${DCDDIR}/extendables/ |
	while read PROGRAM
	  do
		echo "             executing [${PROGRAM}]" | tee -a ${STATUSFILE}
		case "${PROGRAM}" in
		  *.sas)	${SASHOME}/SASFoundation/${SAS_VERSION}/sas ${DCDDIR}/extendables/${PROGRAM} > ${TARDIR}/extendables/${PROGRAM}.output 2>&1
				;;
		  *)		${PROGRAM}
				;;
		esac
	  done
}

populate_tardir ()
{
	calculate_space_requirements.sh 
	RC=$?
	if [ ${RC} -eq 0 ]
          then	echo "           populating tar source directory" | tee -a ${STATUSFILE}
        	while read ITEM 
                  do
			case ${ITEM} in
			  ${SASCONFIG}*)	SOURCE=`echo ${ITEM} | sed "s;^${SASCONFIG}/;;"`
						TARGET=${TARDIR}/SASCONFIG
						mkdir ${TARGET} >/dev/null 2>&1
						cd ${SASCONFIG}
						;;
			  ${SASHOME}*)		SOURCE=`echo ${ITEM} | sed "s;^${SASHOME}/;;"`
						TARGET=${TARDIR}/SASHOME
						mkdir ${TARGET} >/dev/null 2>&1
						cd ${SASHOME}
						;;
			  ${HOME}*)		SOURCE=`echo ${ITEM} | sed "s;^${HOME}/;;"`
						TARGET=${TARDIR}/HOME
						mkdir ${TARGET} >/dev/null 2>&1
						cd ${HOME}
						;;
			  ${DEPOT}*)		SOURCE=`echo ${ITEM} | sed "s;^${DEPOT}/;;"`
						TARGET=${TARDIR}/DEPOT
						mkdir ${TARGET} >/dev/null 2>&1
						cd ${DEPOT}
						;;
			  *)			echo "             could not correlate item [${ITEM}] to a known absolute path" >> ${STATUSFILE}
						;;
			esac
			RMLIST="${RMLIST} ${TARGET}"
                    	DIR=${SOURCE%/*}
			mkdir -p "${TARGET}/${DIR}" >/dev/null 2>&1
			cp -rp "${SOURCE}" "${TARGET}/${DIR}/" >/dev/null 2>&1
                done <${LIST}
		get_extendables
	 	mask_cleartext_passwords
		create_tarfile
	fi
}

ftp_tarfile ()
{
	echo "<<ACTION>> Please see SASNote http://support.sas.com/kb/20941 to ftp the collection in [${TARDIR}] to SAS Technical Support"
}

deployment ()
{
	if [ -d "${SASHOME}/InstallMisc/InstallLogs" ]
	  then	find ${SASHOME}/InstallMisc/InstallLogs -mtime -${DAYS} -print >>${LIST}
	fi
	if [ -d "${HOME}/.SASAppData/SASDeploymentWizard" ]
	  then	find ${HOME}/.SASAppData/SASDeploymentWizard -mtime -${DAYS} -print >>${LIST}
	fi
	if [ -d "${SASLEVEL}/Logs/Configure" ]
	  then	find ${SASLEVEL}/Logs/Configure -mtime -${DAYS} -print >> ${LIST}
	fi
	if [ -f "${PLAN_FILE}" ]
  	  then  echo "${PLAN_FILE}" >>${LIST}
	fi
	populate_tardir
}

running ()
{
        SASWEB="${SASLEVEL}/Web"
        if [ -d "${SASWEB}/WebAppServer" ]
          then  find ${SASWEB}/WebAppServer -name 'setenv.sh' -print >>${LIST}
	fi
	if [ -d "${SASWEB}/gemfire" ] 
	  then	find ${SASWEB}/gemfire -name '*.sh' -print >>${LIST}
	fi
	if [ -d "${SASWEB}/SASEnvironmentManager/agent-5.0.0-EE/" ]
	  then	find ${SASWEB}/SASEnvironmentManager/agent-5.0.0-EE -name '*.sh' >>${LIST}
	fi
	if [ -d "${SASLEVEL}/Logs/Configure" ]
          then	find ${SASLEVEL}/Logs/Configure -print >>${LIST}
        fi
	EXCLUDELIST="/Backup/|/Backups/|/server-backup_|/Temp/|/temp/|/DeploymentTesterServer/|/Logs/Configure/|/kahadb/|/Applications/|/Scripts/|/Utilities/|/AppData/|/sas_webapps/|/tmlog"
	case "${DAYS}" in
	  0)	find ${SASLEVEL} -name '*.log' -print | egrep -v "${EXCLUDELIST}" >>${LIST}
        	find ${SASLEVEL} -name '*.txt' -print | egrep -v "${EXCLUDELIST}" >>${LIST}
		;;
	  *)	find ${SASLEVEL} -name '*.log' -mtime -${DAYS} -print | egrep -v "${EXCLUDELIST}" >>${LIST}
        	find ${SASLEVEL} -name '*.txt' -mtime -${DAYS} -print | egrep -v "${EXCLUDELIST}" >>${LIST}
		;;
	esac
        find ${SASLEVEL} -name '*.xml'  -print | egrep -v "${EXCLUDELIST}" >>${LIST}                  
        find ${SASLEVEL} -name '*.conf' -print | egrep -v "${EXCLUDELIST}" >>${LIST}                
        find ${SASLEVEL} -name '*.cfg'  -print | egrep -v "${EXCLUDELIST}" >>${LIST}                  
        find ${SASLEVEL} -name '*.properties' -print | egrep -v "${EXCLUDELIST}" >>${LIST}          
        populate_tardir
}

cleanup ()
{
	if [ ${RC} -eq 0 ]
	  then	rm -rf ${RMLIST} >/dev/null 2>&1
	  else	rm -rf ${TARDIR} ${TMPFILE} >/dev/null 2>&1
	fi
}

#main
PROG=`basename $0`
ID=`id -n -u`
if [ "${ID}" = "root" ]
  then	echo "<<ERROR>> program cannot be run by the root userid"
	exit 1
fi
DCDDIR=`type ${PROG} 2>&1`
if [ $? -eq 0 ]
  then	CHKDIR=`echo ${DCDDIR} | awk '{ print $3 }'`
  else	cd `dirname ${0}`
	CHKDIR=`pwd`/${PROG}
fi
DCDDIR=`dirname ${CHKDIR}`
export PATH=${PATH}:${DCDDIR}
ARGS=${*}
RC=0
while getopts ":v:t:l:d:ef" OPT
  do
        case ${OPT} in
          v)    export SAS_VERSION=${OPTARG}
                ;;
          t)    export TRACK=${OPTARG}
                ;;
          l)    export LOGTYPE=${OPTARG}
                ;;
          d)    export DAYS=${OPTARG}
                ;;
          e)    export EXTENDABLESONLY="yes"
                ;;
          \?)   echo "<<ERROR>>  Invalid option: -${OPTARG}"
                usage
                ;;
          :)    echo "<<ERROR>>  Argument required for option: -${OPTARG}"
                usage
                ;;
        esac
  done
validate_arguments
if [ ${RC} -eq 0 ]
  then	create_details_file
	if [ "${EXTENDABLESONLY}" = "yes" ]
	  then	get_extendables
		create_tarfile
	  else	${LOGTYPE}
	fi
fi
cleanup
exit ${RC}
