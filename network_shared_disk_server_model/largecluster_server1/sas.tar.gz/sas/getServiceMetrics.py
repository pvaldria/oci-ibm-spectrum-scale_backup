#!/usr/bin/env python
#
# getServiceMetrics.py
#
# Usage
#
#   getServiceMetrics.py [-h] [-user USER] [-password PASSWORD]
#                        [-debug] [-nologging] [-prettyprint]
#                        [-outputloc OUTPUTLOC]
#
#        optional arguments:
#            -h, --help          show this help message and exit
#            -user USER          user id to connect with
#            -password PASSWORD  password used to connect with
#            -debug              prints useful debug information
#            -nologging          prevents any log messages from being displayed
#            -prettyprint        prints a tabular format of a given service's
#                                metrics
#            -outputloc          directory to save the metrics to
#
# Return Codes
#
# 0            - Success
# ENOENT       - No such file or directory
# ESRCH        - No such process
# EPERM        - Operation not permitted
# ENXIO        - No such device or address
# ECONNREFUSED - Connection refused
# ?            - Any return from subprocess.Popen()

import argparse
from datetime import datetime
import errno
import getpass
import json
import logging
import os
import socket
import support_utilities as s_u
import sys
import time
from timeit import default_timer
import urllib2

# Create Logger
logger = logging.getLogger(__name__)

# Make sure Pyton 2 is being used
if sys.version_info[0] >= 3:
    raise AssertionError('This program runs under Python 2')


def main():

    # Parse the command line
    parser = argparse.ArgumentParser(description='Obtains service metrics')
    parser.add_argument('-user', help='user id to connect with')
    parser.add_argument('-password', help='password used to connect with')
    parser.add_argument('-debug', action='store_true',
                        help='prints useful debug information')
    parser.add_argument('-nologging', action='store_true',
                        help='prevents any log messages from being displayed')
    parser.add_argument('-prettyprint', action='store_true',
                        help='prints a tabular format of a given \
                             service\'s metrics')
    parser.add_argument('-outputloc', help='output location for metrics log')
    args = parser.parse_args()

    # Set the default log level to INFO unless otherwise directed
    level = logging.INFO
    if args.debug:
        level = logging.DEBUG

    # Set the logging configuration
    format = '%(levelname)s: %(asctime)-15s %(message)s'
    logging.basicConfig(level=level, format=format)

    # Turn off all logging if the user desires
    if args.nologging:
        logger.disabled = True

    # DEBUG
    logger.debug('Command line arguments - %s', str(args))

    # Assorted constants
    CSQ = '/opt/sas/viya/home/bin/sas-csq'
    CONSUL_CMD_ARG = 'consul-status'
    SERVICE_CMD_TAG = '--service'
    ALL_NODES_TAG = '--allnodes'
    LIST_CMD_ARG = 'list-services'
    INFO_CMD_ARG = 'service-info'
    METRICS = 'commons/metrics'

    # Let the user know things are progressing
    print('Starting analysis of this deployment.')

    # Verify CSQ exists on the system
    if not os.path.exists(CSQ):
        print('%s not found. Is SAS Viya deployed on this system?' % CSQ)
        logger.critical('%s not found.', CSQ)
        return errno.ENOENT

    # Now verify that consul is running
    csstat_out, csstat_err =\
        s_u.launchProcess([CSQ, CONSUL_CMD_ARG])

    # Any errors returned? If so, log and exit
    if (len(csstat_err) > 0) and ('error' in csstat_err):
        print('SAS Viya Consul appears to be down.')
        print('Program aborting.')
        logger.critical('SAS Viya Consul is not available - %s', csstat_out)
        return errno.ESRCH

    # Consul is available
    else:
        logger.info('SAS Viya Consul is available.')

    # Find all machines with httpd in order to talk to SASLogon
    httpd_out, httpd_err =\
        s_u.launchProcess([CSQ, INFO_CMD_ARG, ALL_NODES_TAG,
                           SERVICE_CMD_TAG, 'httpd'])

    # Any errors? If so, log, report, and exit
    if (len(httpd_err) > 0) and ('error' in httpd_err):
        print('Unable to execute %s.' % CSQ)
        print('Program Aborting.')
        logger.critical(httpd_err)
        return errno.EPERM

    # Take the output and convert to json for manipulation
    parsed_httpout = json.loads(httpd_out)

    # Assume there isn't a valid httpd system
    found_valid_httpd = False

    # Loop through the json, looking for a valid host and port
    for system in parsed_httpout:

        # If we find a valid system, set the host and port and move on
        if s_u.validateHostandPort(system['Address'], system['ServicePort']):
            found_valid_httpd = True
            httpd_host = socket.getfqdn(system['Address'])
            httpd_port = system['ServicePort']
            logger.info('Valid httpd system found.')
            break

    # If there are no valid systems, inform the user and bail
    if not found_valid_httpd:
        print('No available systems to access.')
        print('Program Aborting')
        return errno.ENXIO

    logger.debug('httpd host is %s', httpd_host)
    logger.debug('httpd port is %s', httpd_port)

    # Deterime the username
    if not args.user:
        logger.debug('Requesting username')
        print('Please enter the credentials you wish to connect with.\n')
        user = raw_input('Username: ')
    else:
        logger.debug('username passed via command line')
        user = args.user

    # Deterime the password for the given user
    if not args.password:
        logger.debug('Requesting password')
        passwd = getpass.getpass('Password for %s:' % user)
    else:
        logger.debug('password passed via command line')
        passwd = args.password

    logger.info('Credentials obtained.')

    # Build the url to connect with and the information to send
    sl_url = 'http://%s:%s/SASLogon/oauth/token' % (httpd_host, httpd_port)
    logger.debug('url to use: %s', sl_url)
    sl_data = 'grant_type=password&username=%s&password=%s' % (user, passwd)
    logger.debug('asking for a grant type for user (%s) with password', user)

    # Obtain an authentication token from the logon service via user/pass

    try:

        # Start a timer
        sl_start = default_timer()
        logger.debug('wall clock start time %s', sl_start)

        sl_auth = s_u.basic_authorization('sas.ec', '')

        sl_headers = {'Accept': 'application/json',
                      'Content-Type': 'application/x-www-form-urlencoded',
                      'Authorization': sl_auth}

        sl_req = urllib2.Request(sl_url, headers=sl_headers, data=sl_data)

        # DEBUG
        logger.debug('request is %s', sl_req)

        # Now open the connection and read the response
        sl_response = urllib2.urlopen(sl_req)
        logger.debug('response is %s', sl_response)
        sl_read_response = sl_response.read()
        logger.debug('response read successfully')

        # Parse the response to get auth token
        jdata = json.loads(sl_read_response)
        auth_header = " bearer " + jdata["access_token"]

        # Operation complete, compute time used
        sl_end = default_timer()
        logger.debug('wall clock end time %s', sl_end)

        # Total time used?
        sl_elapsed = sl_end - sl_start
        logger.debug('elapsed wall clock time %s', sl_elapsed)

        # Close the connection
        sl_response.close()

        logger.debug('auth token obtained successfully')
        logger.info('Connection to the SAS Logon service was successful.')

    except Exception as authE:

        # Close the connection if it was opened
        if 'sl_response' in locals():
            logger.debug('Closing the response handle %s', sl_response)
            sl_response.close()

        # Log what happened and inform the user
        logger.critical(authE)
        print('Cannot obtain authentication token as %s was returned.' % authE)
        print('Program aborting.')
        return errno.ECONNREFUSED

    # Now, ask consul what all applications it knows about
    available_apps, available_app_errors =\
        s_u.launchProcess([CSQ, LIST_CMD_ARG])

    # Any errors? If so, log, report, and exit
    if (len(available_app_errors) > 0) and ('error' in available_app_errors):
        print('Unable to execute %s.' % CSQ)
        print('Program Aborting.')
        logger.critical(available_app_errors)
        return errno.EPERM

    # As the output can be voluminous, write it to a file
    dts = datetime.now()
    output_directory = '.'
    filename = 'metrics_output_%s.log' % dts.strftime('%Y-%m-%d-%H.%M.%S')
    filepath = os.path.realpath(os.path.join(os.getcwd(), filename))

    # Did the user specify an output location?
    if args.outputloc:

        # They did, so see if we can use it
        if os.path.isdir(args.outputloc):
            filepath = os.path.realpath(os.path.join(args.outputloc,
                                                     filename))
        else:
            logger.warn('The path specified, %s, did not exit.',
                        args.outputloc)
            logger.warn('Using the current directory instead.')

    # Is the chosen path writable?
    if not os.access(os.path.dirname(filepath), os.W_OK):
        print('%s is not writiable.' % os.path.dirname(filename))
        print('Program Aborting.')
        logger.critical('%s is not writiable.', os.path.dirname(filename))
        return errno.EPERM

    # What's the path being used?
    logger.debug('filepath %s is being used and is writable.', filepath)

    # Open the file now and grab a handle
    file_handle = open(filepath, 'w')

    # Count the number of services processed
    number_processed = 0

    # For each service, obtain its metrics
    for app in available_apps.splitlines():

        # Find out information about the current service
        app_out, app_err =\
            s_u.launchProcess([CSQ, INFO_CMD_ARG, ALL_NODES_TAG,
                               SERVICE_CMD_TAG, app])

        # Any errors? If so, log, report, and exit
        if (len(app_err) > 0) and ('error' in app_err):
            print('Unable to execute %s.' % CSQ)
            print('Program Aborting.')
            logger.critical(app_err)
            return errno.EPERM

        # Parse the output as json
        parsed_appout = json.loads(app_out)

        # Iterate through the parsed output
        for item in parsed_appout:

            # Make sure the item is a microservice that we can
            # obtain metrics for
            if 'proxy' in item['ServiceTags']:

                # Build the URL using the context provided
                item_url = 'http://%s:%s/%s/%s' % (socket.getfqdn(
                    item['Address']),
                    item['ServicePort'],
                    item['ServiceName'],
                    METRICS)
                logger.debug('URL to use - %s', item_url)

                # Start a timer
                item_start = default_timer()

                # Attempt to make request for this service's metrics
                try:

                    # Build the request
                    item_req = urllib2.Request(item_url)
                    item_req.add_header('Authorization', auth_header)

                    # Make the request
                    item_response = urllib2.urlopen(item_req)

                    # Check the response
                    item_read_code = item_response.getcode()

                    # Finished; record the current time and then the time
                    # elapsed
                    item_end = default_timer()
                    item_elapsed = item_end - item_start

                    # Read the response
                    read_item_response = item_response.read()

                    # Store the read response as loaded json for further
                    # manipulation
                    dumped_response = json.loads(read_item_response)

                    # If formatted output has been requested, do so now
                    if args.prettyprint:

                        # Build the formatted results string
                        results = ""

                        # For each key in the response, format the
                        # (key,value) in a tabular form
                        for key in dumped_response:
                            results += "%s:%s\n" % (' '.join(
                                [x.capitalize() for x in
                                 key.split('.')]).ljust(
                                60), str(dumped_response[key]).rjust(20))

                        # Display information about the current services and
                        # its metrics
                        print('\nService [%s] running on host [%s] returned a'
                              '[%s] code and the following metrics:' %
                              (item['ServiceName'], socket.getfqdn(
                                  item['Address']),
                                  str(item_read_code)))
                        print(results)

                    # Output the information to the file
                    output_string = '%s, %s, %s, %s, %s, %s\n' % (
                        socket.getfqdn(
                            item['Address']),
                        item['ServiceName'],
                        time.strftime("%Y-%m-%d,%H:%M"),
                        str(item_read_code),
                        str(item_elapsed),
                        json.dumps(read_item_response))
                    file_handle.write(output_string)

                    # Close the response as we're done with this service
                    item_response.close()

                    # Count this service as processed
                    number_processed += 1

                except Exception as itemE:

                    # Close the connection if it was opened
                    if 'item_response' in locals():
                        logger.debug(
                            'Closing the response handle %s', item_response)
                        item_response.close()

                    # Inform the user there was a problem obtaining metrics for
                    # the current service

                    if "HTTP Error 404" in str(itemE):

                        # Some applications doesn't offer metrics, even though
                        # they're proxied
                        print('%s does not offer metrics. Skipping...' %
                              item['ServiceName'])
                        logger.info(
                            '%s does not offer metrics. Skipping...',
                            item['ServiceName'])
                    else:

                        # An error occurred
                        print('There was a failure (%s) obtaining the '
                              'metrics for %s on %s. Skipping...' %
                              (str(item_read_code), item['ServiceName'],
                               socket.getfqdn(item['Address'])))

                        logger.critical('failure obtaining metrics for %s',
                                        item['ServiceName'])
                        logger.critical('caught exception - %s', str(itemE))

    # Close the output file
    file_handle.close()

    # Report the total processed
    logger.info('There were %s services processed.', str(number_processed))

    # Let the user know we're done
    print('Output written to %s.' % os.path.realpath(filename))
    print('Application completed successfully. Exiting...')

# Begin program
if __name__ == '__main__':
    sys.exit(main())
