#!/usr/bin/env python
#
# refreshTablesInCAS.py
#
# Usage
#
#    refreshTablesInCAS.py [-h] [-user USER] [-password PASSWORD]
#                          [-server SERVER] [-caslib CASLIB] [-d] [-v]
#                          [-nologging]
#
#        optional arguments:
#            -h, --help          show this help message and exit
#            -user USER          user id to connect with
#            -password PASSWORD  password used to connect with
#            -server SERVER      CAS server to use
#            -caslib CASLIB      caslib to load data into
#            -d, --debug         prints useful debug information
#            -v, --verbose       prints verbose information
#            -nologging          prevents any log messages from being displayed
#
# Return Codes
#
# 0            - Success
# ENOENT       - No such file or directory
# ESRCH        - No such process
# EPERM        - Operation not permitted
# ENXIO        - No such device or address
# ECONNREFUSED - Connection refused
# ?            - Any return from subprocess.Popen()

import argparse
import errno
import getpass
import json
import logging
import support_utilities as s_u
import sys
import urllib2


# Create Logger
logger = logging.getLogger(__name__)

# Make sure Pyton 2 is being used
if sys.version_info[0] >= 3:
    raise AssertionError('This program runs under Python 2')


def main():

    # Parse the command line
    parser = argparse.ArgumentParser(description='Makes sure all tables in \
                                     the caslib are loaded.')
    parser.add_argument('-user', help='user id to connect with')
    parser.add_argument('-password', help='password used to connect with')
    parser.add_argument('-server', help='CAS server to use')
    parser.add_argument('-caslib', help='caslib to load data into')
    parser.add_argument('-d', '--debug', action='store_const',
                        dest='loglevel', const=logging.DEBUG,
                        default=logging.WARNING,
                        help='prints useful debug information')
    parser.add_argument('-v', '--verbose', action='store_const',
                        dest='loglevel', const=logging.INFO,
                        help='prints verbose information')
    parser.add_argument('-nologging', action='store_true',
                        help='prevents any log messages from being displayed')
    args = parser.parse_args()

    # Set the logging configuration
    format = '%(levelname)s: %(asctime)-15s %(message)s'
    logging.basicConfig(level=args.loglevel, format=format)

    # Turn off all logging if the user desires
    if args.nologging:
        logger.disabled = True

    # DEBUG
    logger.debug('Command line arguments - %s', str(args))

    # Assorted constants
    SASLOGON = 'SASLogon/oauth/token'
    CASMGMT_SERVERS = 'casManagement/servers'
    CASLIBS = 'caslibs'
    TABLES = 'tables'

    # Check to see if the user has asked for something
    if ((not args.server) or (not args.caslib)):

        # Inform the user and error out
        cmderr = 'The server and caslib to use must be specified.'
        print('\n%s\n' % cmderr)
        logger.error('%s\n', cmderr)
        parser.print_help()
        print('\n')
        return errno.EPERM

    # Let the user know things are progressing
    print('Starting table refresh in this deployment.\n')

    # Verify CSQ exists on the system
    if not s_u.isSystemValid():
        return errno.ENOENT

    # Verify Consul is active
    consul_status = s_u.validateConsul()
    if not consul_status:
        return consul_status

    # Determine a valid HTTP system to talk to
    httpd_host, httpd_port = s_u.getHTTPDHostAndPort()

    # If no system is found, abort the application
    if (str(httpd_host) is None) or (str(httpd_port) is None):
        return errno.ENXIO

    logger.debug('httpd host is %s', httpd_host)
    logger.debug('httpd port is %s', httpd_port)

    # Deterime the username
    if not args.user:
        logger.debug('Requesting username')
        print('Please enter the credentials you wish to connect with.\n')
        user = raw_input('Username: ')
    else:
        logger.debug('username passed via command line')
        user = args.user

    # Determine the password for the given user
    if not args.password:
        logger.debug('Requesting password')
        passwd = getpass.getpass('Password for %s:' % user)
    else:
        logger.debug('password passed via command line')
        passwd = args.password

    logger.info('Credentials obtained.')

    # Obtain the auth token
    sl_url = 'http://%s:%s/%s' % (httpd_host, httpd_port, SASLOGON)
    rc, auth_header = s_u.getAuthToken(sl_url, user, passwd)

    # Was the auth token obtained? If not, exit
    if ((rc != s_u.SUCCESS) or (auth_header is None)):
        return rc

    # Build the url to use in refreshing the tables
    srv_url = 'http://%s:%s/%s/%s/%s' % (httpd_host, httpd_port,
                                         CASMGMT_SERVERS, args.server, CASLIBS)

    # Now obtain the tables for this caslib and CAS server
    trc, tables = s_u.getServerTables(args.caslib, srv_url, auth_header)

    # Keep track of failures
    issues_found = False

    # Was the lists of tables for this library obtainable?
    if ((trc != s_u.SUCCESS) or (tables is None)):
        msg = 'Could not obtain list of tables for caslib'
        logger.error('%s %s.', msg, args.caslib)
        print('\nApplication completed with errors. Exiting...')

    else:

        # Do we have the tables for the current library
        if len(tables) > 0:

            # We do, so loop through refreshing each table
            for table in tables:
                table_url = '%s/%s/%s/%s' % (srv_url, args.caslib, TABLES,
                                             table['name'])
                ref_rc = s_u.refreshTable(table_url, table['name'],
                                          args.caslib, auth_header)

                # All good?
                if ref_rc != s_u.SUCCESS:
                    issues_found = True
        else:

            # There are no tables in this caslib
            print('WARNING: The caslib %s has no tables.' % args.caslib)
            issues_found = True

        if issues_found:
            print('\nApplication completed with errors. Exiting...')
        else:
            print('\nApplication completed successfully. Exiting...')

# Begin program
if __name__ == '__main__':
    sys.exit(main())
