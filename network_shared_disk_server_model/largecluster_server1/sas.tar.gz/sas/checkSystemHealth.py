#!/usr/bin/env python

# checkSystemHealth.py
#
# Usage
#
#   CheckSystemHealth.py [-h | --help] [-debug] [-nologging]
#
#       optional arguments:
#           -h, --help   - shows help message and exits
#           -debug       - prints some useful debugging information
#           -nologging   - prevents any log messages from being displayed
#
# Return Codes
#
#   0      - Success, e.g. the system is healthy
#   EPERM  - user doesn't have sudo (elevated) rights
#   ENOENT - /etc/init.d/sas-viya-all-services not found
#   EAGAIN - The system is unhealthy
#   ?      - Any return code from subprocess.Popen()

# Import required packages

import argparse
import errno
import logging
import os
import support_utilities as s_u
import sys

# Create Logger
logger = logging.getLogger(__name__)

# Make sure Pyton 2 is being used
if sys.version_info[0] >= 3:
    raise AssertionError('This program runs under Python 2')


def main():

    # Parse the command line
    parser = argparse.ArgumentParser(description='Checks system status \
                                     for services and applications \
                                     registered in Consul')
    parser.add_argument('-debug', action='store_true',
                        help='prints useful debug information')
    parser.add_argument('-nologging', action='store_true',
                        help='prevents any log messages from being displayed')
    args = parser.parse_args()

    # Set the default log level to INFO unless otherwise directed
    level = logging.INFO
    if args.debug:
        level = logging.DEBUG

    # Set the logging configuration
    format = '%(levelname)s: %(asctime)-15s %(message)s'
    logging.basicConfig(level=level, format=format)

    # Turn off all logging if the user desires
    if args.nologging:
        logger.disabled = True

    # DEBUG
    logger.debug('Command line arguments - %s', str(args))

    # Assorted constants
    CSQ = '/opt/sas/viya/home/bin/sas-csq'
    CONSUL_CMD_ARG = 'consul-status'
    SERVICE_CMD_TAG = '--service'
    ALL_NODES_TAG = '--allnodes'
    LIST_CMD_ARG = 'list-services'
    INFO_CMD_ARG = 'service-info'
    HEALTH_CMD_ARG = 'service-health'
    METRICS = 'commons/metrics'

    # Let the user know things are progressing
    print('Starting analysis of this deployment.')

    # Verify CSQ exists on the system
    if not os.path.exists(CSQ):
        print('%s not found. Is SAS Viya deployed on this system?' % CSQ)
        logger.critical('%s not found.', CSQ)
        return errno.ENOENT

    # Now verify that consul is running and is available
    csstat_out, csstat_err = s_u.launchProcess([CSQ, CONSUL_CMD_ARG])

    # Any errors returned? If so, log and exit
    if (len(csstat_err) > 0) and ('error' in csstat_err):
        print('Consul appears to be down.')
        print('Program aborting.')
        logger.critical('Consul is not available - %s', csstat_out)
        return errno.ESRCH

    # Consul is available
    else:
        logger.debug('Consul is available.')

    # Now, ask consul what all applications it knows about
    available_apps, available_app_errors =\
        s_u.launchProcess([CSQ, LIST_CMD_ARG])

    # Any errors? If so, log, report, and exit
    if (len(available_app_errors) > 0) and ('error' in available_app_errors):
        print('Unable to execute %s.' % CSQ)
        print('Program Aborting.')
        logger.critical(available_app_errors)
        return errno.EPERM

    # For each services, determine the number of instances and report health

    # Initialization
    hosts = set()
    notRegistered = set()
    health_dict = {}

    # Process each known service
    for app in available_apps.splitlines():

        # Find out information about the current service
        app_out, app_err =\
            s_u.launchProcess([CSQ, HEALTH_CMD_ARG, ALL_NODES_TAG,
                              SERVICE_CMD_TAG, app])

        # Any errors? If so, log, report, and exit
        if (len(app_err) > 0) and ('error' in app_err):
            print('Unable to execute %s.' % CSQ)
            print('Program Aborting.')
            logger.critical(app_err)
            return errno.EPERM

        # If the application suddenly is not registered in Consul
        # but was initially, record this
        if 'NOT_REGISTERED' in app_out:
            notRegistered.add(app)

        # Build the list of hosts registered in Consul and
        # store the metrics in the dictionary
        else:
            for metric in app_out.splitlines():
                hosts.add(metric[:metric.find(',')])
            health_dict[app] = app_out

    # Assume the system is healthy and that there are no unhealthy applications
    healthy = True
    unhealthy_apps = []

    # Iterate through the dictionary, checking the metrics for unhealthy values
    for service, health in health_dict.items():
        if (('warning' in health) or ('critical' in health) or
           ('fatal' in health)):

            # The system is unhealthy; update and move on
            unhealthy_apps.append(service)
            healthy = False

    # Display the known hosts
    print('\nThe hosts currently known to Consul in this deployment are:\n')
    for host in sorted(hosts):
        print('\t%s' % host)

    # Is the system healthy; if so, report this information and return success
    if healthy:
        print('\nNo issues were found in this deployment;'),
        print('the system is healthy.\n')
        return 0

    # The deployment is not healthy; inform the user of the issues
    else:
        print('\nThis deployment is not healthy.\n')
        print('The following applications show issues on the given hosts:\n')
        for app in unhealthy_apps:
            print('%s\n' % app)
            for item in health_dict[app].splitlines():
                if 'passing' not in item:
                    print('\t%s' % item)
            print('\n')
        return errno.EAGAIN

# Begin program
if __name__ == '__main__':
    sys.exit(main())
