#!/bin/bash
#
# Copyright 2017,  SAS Institute Inc.,  Cary, NC  USA
# All rights reserved.  Produced in the United States of AMerica
#

# default values (may be edited)
HOST_NAME_DEFAULT=defaulthost.com #<<==host where cas-formats and login services are running
PORT_DEFAULT=80 #<<==probably always 80
USER_NAME_DEFAULT=va_user_id
PASSWORD_DEFAULT=va_user_pw
CAS_SERVER_DEFAULT=cas-default-server
CAS_FMT_LIB_NAME_DEFAULT=userformats1
CAS_FMT_LIB_ITEM_STORE_DEFAULT=/tmp/va_fmts_itemstore
CAS_FMT_LIB_CASLIB_DEFAULT=Formats
CAS_FMT_LIB_TABLE_DEFAULT=userformats1

# oauth
AUTH_FRAGMENT="/SASLogon/oauth/token?grant_type=password&";
AUTH_FRAGMENT_LOGOUT="/SASLogon/logout.do";
TRUST_CREDENTIAL="Basic c2FzLm1vYmlsZWJpOg==";

# logon
function doRequestLogon() {
   user_credential="username=$USER_NAME&password=$PASSWORD"
   target_uri="http://$HOST_NAME:$PORT$AUTH_FRAGMENT$user_credential"
   result=$(curl -H "Authorization: $TRUST_CREDENTIAL" -X POST $target_uri -c cookies.txt);
   array=(${result//:/ })
   retval=${array[1]}
   retval=${retval:1:${#retval} - 15}
   echo "Bearer $retval"
}

# logoff
function doRequestLogOff() {
   user_credential="username=$USER_NAME&password=$PASSWORD"
   target_uri="http://$HOST_NAME:$PORT$AUTH_FRAGMENT_LOGOUT"
   
   echo "curl -H "Authorization: $TRUST_CREDENTIAL" -X POST $target_uri -b cookies.txt"
   
   result=$(curl -H "Authorization: $TRUST_CREDENTIAL" -X POST $target_uri -b cookies.txt);
   array=(${result//:/ })
   retval=${array[1]}
   retval=${retval:1:${#retval} - 15}
   echo "Bearer $retval"
   
   rm cookies.txt
}

# url encoding
urlencode() {
    # urlencode <string>
    # https://gist.github.com/cdown/1163649
    local length="${#1}"
    for (( i = 0; i < length; i++ )); do
        local c="${1:i:1}"
        case $c in
            [a-zA-Z0-9.~_-]) printf "$c" ;;
            *) printf '%s' "$c" | xxd -p -c1 |
                   while read c; do printf '%%%s' "$c"; done ;;
        esac
    done
}

# prompt user for values
printf "Enter host name (default $HOST_NAME_DEFAULT): "
read HOST_NAME
printf "Enter host port (default $PORT_DEFAULT): "
read PORT
printf "Enter username (default $USER_NAME_DEFAULT): "  
read USER_NAME
printf "Enter password (default $PASSWORD_DEFAULT): "  
while IFS= read -r -s -n1 pass; do
  if [[ -z $pass ]]; then
     echo
     break
  else
     echo -n '*'
     PASSWORD+=$pass
  fi
done
printf "Enter CAS server ID (default $CAS_SERVER_DEFAULT): "  
read CAS_SERVER
printf "Enter CAS session ID (default: create a new, temporary, one): "  
read CAS_SESSION_ID
printf "Enter CAS format library name (default: $CAS_FMT_LIB_NAME_DEFAULT): "  
read CAS_FMT_LIB_NAME
printf "Enter location of item store (default: $CAS_FMT_LIB_ITEM_STORE_DEFAULT): "  
read CAS_FMT_LIB_ITEM_STORE
printf "Create global format library? (y or n (default is n)): "  
read CAS_FMT_LIB_GLOBAL
printf "Caslib to store format library in? (default: $CAS_FMT_LIB_CASLIB_DEFAULT): "  
read CAS_FMT_LIB_CASLIB
printf "Table to store format library in? (default: $CAS_FMT_LIB_TABLE_DEFAULT): "  
read CAS_FMT_LIB_TABLE

# use defaults if user did not provide value
if [ ! -n "$HOST_NAME" ]
then
   HOST_NAME=$HOST_NAME_DEFAULT
fi
if [ ! -n "$PORT" ]
then
   PORT=$PORT_DEFAULT
fi
if [ ! -n "$USER_NAME" ]
then
   USER_NAME=$USER_NAME_DEFAULT
fi
if [ ! -n "$PASSWORD" ]
then
   PASSWORD=$PASSWORD_DEFAULT
fi
PASSWORD=$(urlencode $PASSWORD)
if [ ! -n "$CAS_SERVER" ]
then
   CAS_SERVER=$CAS_SERVER_DEFAULT
fi
if [ ! -n "$CAS_FMT_LIB_NAME" ]
then
   CAS_FMT_LIB_NAME=$CAS_FMT_LIB_NAME_DEFAULT
fi
if [ ! -n "$CAS_FMT_LIB_ITEM_STORE" ]
then
   CAS_FMT_LIB_ITEM_STORE=$CAS_FMT_LIB_ITEM_STORE_DEFAULT
fi
if [ "y" == "$CAS_FMT_LIB_GLOBAL" ]
then
   CAS_FMT_LIB_GLOBAL=',"scope":"global"'
else
   CAS_FMT_LIB_GLOBAL=""
fi
if [ ! -n "$CAS_FMT_LIB_CASLIB" ]
then
   CAS_FMT_LIB_CASLIB=$CAS_FMT_LIB_CASLIB_DEFAULT
fi
if [ ! -n "$CAS_FMT_LIB_TABLE" ]
then
   CAS_FMT_LIB_TABLE=$CAS_FMT_LIB_TABLE_DEFAULT
fi

# authenticate and get an oauth token
echo
echo
echo "******************  Need to create an Oauth token.  ***************************"
echo
AUTH_HEADER=$(doRequestLogon)

# create a cas session
if [ ! -n "$CAS_SESSION_ID" ]
then
   echo
   echo "******************  Need to create a cas session ID.  ***************************"
   echo
   CAS_SESSION_JSON='{"name":"sessionFromImportFormatLibraryScript","nodes":"1"}'

   echo payload=$CAS_SESSION_JSON

   # Get cas session id.
   SERVICE=casManagement
   ENDPOINT=servers/$CAS_SERVER/sessions
   echo "curl -H 'Accept: application/json' -H "Authorization: $AUTH_HEADER" -H 'Content-Type: application/vnd.sas.cas.session+json' -X POST -d $CAS_SESSION_JSON http://$HOST_NAME:$PORT/$SERVICE/$ENDPOINT"
   result=$(curl -H "Accept: application/json" -H "Authorization: $AUTH_HEADER" -H "Content-Type: application/vnd.sas.cas.session+json" -X POST -d $CAS_SESSION_JSON http://$HOST_NAME:$PORT/$SERVICE/$ENDPOINT);
   echo
   echo
   echo result: $result
   array=(${result//:/ })
   retval=${array[2]}
   CAS_SESSION_ID=${retval:1:${#retval} - 9}
   echo
   echo CAS session ID to use for this script is $CAS_SESSION_ID
   echo
fi

# create a format library from the itemstore
echo
echo "******************  Going to create format library from item store.  ***************************"
echo
FMTLIB_JSON='{"version":1,"libraryName":"'
FMTLIB_JSON+=$CAS_FMT_LIB_NAME 
FMTLIB_JSON+='","type":"itemStore","sourceUri":"itemstore:'
FMTLIB_JSON+=$CAS_FMT_LIB_ITEM_STORE 
FMTLIB_JSON+='"'
FMTLIB_JSON+=$CAS_FMT_LIB_GLOBAL
FMTLIB_JSON+='}'

echo payload=$FMTLIB_JSON

SERVICE=casFormats
ENDPOINT=servers/$CAS_SERVER/formatLibraries?sessionId=$CAS_SESSION_ID
echo "POST: http://$HOST_NAME:$PORT/$SERVICE/$ENDPOINT"
curl -H "Accept: application/json" -H "Authorization: $AUTH_HEADER" -H "Content-Type: application/vnd.sas.cas.format.source+json" -X POST -d $FMTLIB_JSON http://$HOST_NAME:$PORT/$SERVICE/$ENDPOINT
echo
echo

# save a copy of the format library to disk as a sashdat (for recovery if server fails)
echo
echo "******************  Going to persist format library to table (NOTE: on disk only, won't appear in caslib in memory).  ***************************"
echo

FMTLIB_PERSIST_JSON='{"version":1,"caslibName":"'
FMTLIB_PERSIST_JSON+=$CAS_FMT_LIB_CASLIB 
FMTLIB_PERSIST_JSON+='","tableName":"'
FMTLIB_PERSIST_JSON+=$CAS_FMT_LIB_TABLE 
FMTLIB_PERSIST_JSON+='","replace":true}'

echo payload=$FMTLIB_PERSIST_JSON

# Persist format library to table in caslib.  Will only be on disk, not in memory.  This is where config will pick it up from.  
#  Example:
#    cas startup needs to have:  -cfg /some/path/config.lua
#    contents of config.lua:
#          cas.fmtcaslib="Formats"
#          cas.addfmtlib="userFormats1.sashdat"
SERVICE=casFormats
ENDPOINT=servers/$CAS_SERVER/formatLibraries/$CAS_FMT_LIB_NAME_DEFAULT?sessionId=$CAS_SESSION_ID
echo "POST: http://$HOST_NAME:$PORT/$SERVICE/$ENDPOINT"
curl -H "Accept: application/json" -H "Authorization: $AUTH_HEADER" -H "Content-Type: application/vnd.sas.cas.format.persist+json" -X POST -d $FMTLIB_PERSIST_JSON http://$HOST_NAME:$PORT/$SERVICE/$ENDPOINT
echo
echo


echo
echo "******************  Going to logout CAS session.  ***************************"
echo

# Don't leave open sessions.
SERVICE=casManagement
ENDPOINT=servers/$CAS_SERVER/sessions/$CAS_SESSION_ID
echo "DELETE: http://$HOST:$PORT/$SERVICE/$ENDPOINT"
curl -H "Accept: application/json" -H "Authorization: $AUTH_HEADER" -X DELETE http://$HOST_NAME:$PORT/$SERVICE/$ENDPOINT
echo
echo



echo
echo "******************  Going to logout Oauth token.  ***************************"
echo
echo
echo
doRequestLogOff
echo

